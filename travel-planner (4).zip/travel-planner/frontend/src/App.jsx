// ============================================================
// App.jsx — Root component. Manages global state + layout.
// ============================================================

import React, { useState, useEffect } from 'react';
import Sidebar from './components/inputs/Sidebar.jsx';
import MainContent from './components/MainContent.jsx';
import ChatPanel from './components/chat/ChatPanel.jsx';
import Topbar from './components/shared/Topbar.jsx';
import { checkHealth } from './utils/api.js';
import { useChecklist } from './hooks/useChecklist.js';

export default function App() {
  const [tripData, setTripData] = useState({
    fromCity: '', fromCountry: 'India',
    toCountries: [],
    startDate: '', endDate: '',
    numDays: '',
    travelers: 1,
    mustVisitPlaces: [],
    travelStyle: [],
    flightClass: 'economy',
    preferredAirlines: '',
    avoidAirlines: '',
    directOnly: false,
    maxLayover: '',
    hotelVibe: '',
    hotelStars: 4,
    roomType: 'double',
    hotelBudgetPerNight: '',
    hotelAreas: '',
    commutePrefs: [],
    totalBudget: '',
    currency: 'INR',
  });

  // Step 1: overview (cities, flights, hotels, budget)
  const [overview, setOverview] = useState(null);

  // Step 2: expanded days — { "1": { day data }, "3": { day data }, ... }
  const [expandedDays, setExpandedDays] = useState({});

  // Which day panel is open on the right
  const [activeDayPanel, setActiveDayPanel] = useState(null); // { dayNumber, cityName, date }

  const [isGenerating, setIsGenerating] = useState(false);
  const [generateError, setGenerateError] = useState(null);
  const [activeTab, setActiveTab] = useState('itinerary');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [chatOpen, setChatOpen] = useState(true);
  const [backendStatus, setBackendStatus] = useState(null);
  const [manualEntries, setManualEntries] = useState([]);

  useEffect(() => {
    checkHealth()
      .then(data => setBackendStatus(data))
      .catch(() => setBackendStatus({ status: 'error' }));
  }, []);

  const checklist = useChecklist();

  // When a new overview is generated, clear expanded days and close panel
  const handleNewOverview = (newOverview) => {
    setOverview(newOverview);
    setExpandedDays({});
    setActiveDayPanel(null);
  };

  return (
    <div className="app-layout">
      {!sidebarCollapsed && (
        <Sidebar
          tripData={tripData}
          setTripData={setTripData}
          isGenerating={isGenerating}
          setIsGenerating={setIsGenerating}
          setOverview={handleNewOverview}
          setGenerateError={setGenerateError}
          onCollapse={() => setSidebarCollapsed(true)}
          manualEntries={manualEntries}
        />
      )}

      <div className="main-content">
        <Topbar
          overview={overview}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          backendStatus={backendStatus}
          sidebarCollapsed={sidebarCollapsed}
          onExpandSidebar={() => setSidebarCollapsed(false)}
          chatOpen={chatOpen}
          setChatOpen={setChatOpen}
          tripData={tripData}
          manualEntries={manualEntries}
          expandedDays={expandedDays}
          checklist={checklist}
        />
        <MainContent
          overview={overview}
          expandedDays={expandedDays}
          setExpandedDays={setExpandedDays}
          activeDayPanel={activeDayPanel}
          setActiveDayPanel={setActiveDayPanel}
          tripData={tripData}
          activeTab={activeTab}
          isGenerating={isGenerating}
          generateError={generateError}
          manualEntries={manualEntries}
          setManualEntries={setManualEntries}
          checklist={checklist}
        />
      </div>

      {chatOpen && (
        <ChatPanel
          overview={overview}
          expandedDays={expandedDays}
          tripData={tripData}
          onClose={() => setChatOpen(false)}
        />
      )}
    </div>
  );
}
