// ============================================================
// MainContent.jsx — Routes to tab views, manages day panel
// ============================================================

import React from 'react';
import ItineraryView from './itinerary/ItineraryView.jsx';
import BudgetView from './pricing/BudgetView.jsx';
import ComparisonView from './comparison/ComparisonView.jsx';
import ManualEntryView from './shared/ManualEntryView.jsx';
import ApiKeysView from './shared/ApiKeysView.jsx';
import EmptyState from './shared/EmptyState.jsx';

export default function MainContent({
  overview, expandedDays, setExpandedDays,
  activeDayPanel, setActiveDayPanel,
  tripData, activeTab, isGenerating, generateError,
  manualEntries, setManualEntries, checklist
}) {

  // ---- Loading state ----
  if (isGenerating) {
    return (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20, padding: 40 }}>
        <div style={{ position: 'relative' }}>
          <div style={{
            width: 64, height: 64, borderRadius: '50%',
            border: '2px solid var(--border-subtle)',
            borderTop: '2px solid var(--accent-primary)',
            animation: 'spin 1s linear infinite'
          }} />
          <span style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', fontSize: 20 }}>✈️</span>
        </div>
        <div style={{ textAlign: 'center' }}>
          <p style={{ fontFamily: 'var(--font-display)', fontSize: 18, color: 'var(--text-accent)', marginBottom: 8 }}>
            Building your trip overview...
          </p>
          <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            Mapping cities, checking flights, finding hotels — takes about 5–10 seconds
          </p>
          <div style={{ marginTop: 16, display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
            {['🗺️ Planning route', '💰 Estimating budget', '🏨 Finding hotels', '✈️ Checking flights'].map((s, i) => (
              <span key={s} className="tag tag-muted pulse" style={{ animationDelay: `${i * 0.3}s` }}>{s}</span>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ---- Error state ----
  if (generateError) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 40 }}>
        <div style={{ maxWidth: 480, textAlign: 'center' }}>
          <div style={{ fontSize: 40, marginBottom: 16 }}>⚠️</div>
          <h3 style={{ color: 'var(--error)', marginBottom: 8 }}>Generation Failed</h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginBottom: 16 }}>{generateError}</p>
          <div style={{ background: 'var(--bg-card)', borderRadius: 'var(--radius-md)', padding: 16, textAlign: 'left' }}>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 8 }}>Common fixes:</p>
            <ul style={{ fontSize: 12, color: 'var(--text-secondary)', paddingLeft: 16, lineHeight: 2 }}>
              <li>Check that backend is running on port 3001</li>
              <li>Verify ANTHROPIC_API_KEY is set in backend/.env</li>
              <li>Make sure you have Anthropic API credits</li>
            </ul>
          </div>
        </div>
      </div>
    );
  }

  if (activeTab === 'settings') return <ApiKeysView />;
  if (activeTab === 'manual') return <ManualEntryView manualEntries={manualEntries} setManualEntries={setManualEntries} overview={overview} tripData={tripData} />;
  if (!overview) return <EmptyState />;

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      {activeTab === 'itinerary' && (
        <ItineraryView
          overview={overview}
          expandedDays={expandedDays}
          setExpandedDays={setExpandedDays}
          activeDayPanel={activeDayPanel}
          setActiveDayPanel={setActiveDayPanel}
          tripData={tripData}
          checklist={checklist}
        />
      )}
      {activeTab === 'budget' && (
        <BudgetView overview={overview} expandedDays={expandedDays} tripData={tripData} />
      )}
      {activeTab === 'comparison' && (
        <ComparisonView overview={overview} tripData={tripData} />
      )}
    </div>
  );
}
