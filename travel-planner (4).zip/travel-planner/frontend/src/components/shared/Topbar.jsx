// ============================================================
// shared/Topbar.jsx — Top navigation bar
// ============================================================

import React from 'react';
import { PanelLeft, MessageSquare, Download, Globe } from 'lucide-react';
import { exportTrip } from '../../utils/api.js';

export default function Topbar({
  overview, activeTab, setActiveTab, backendStatus,
  sidebarCollapsed, onExpandSidebar, chatOpen, setChatOpen,
  tripData, manualEntries, expandedDays
}) {
  const tabs = [
    { id: 'itinerary', label: 'Itinerary' },
    { id: 'budget', label: 'Budget' },
    { id: 'comparison', label: 'Compare' },
    { id: 'manual', label: 'My Links' },
    { id: 'settings', label: 'API Keys' },
  ];

  const handleExport = async () => {
    if (!overview) return alert('Generate a trip first!');
    try {
      const result = await exportTrip(tripData, overview, manualEntries);
      alert(`✅ Trip saved!\n\nFiles saved to:\n${result.files?.txt}\n\nYou can also copy the text from the clipboard.`);
    } catch (err) {
      alert('Export failed: ' + err.message);
    }
  };

  return (
    <div className="topbar" style={{ justifyContent: 'space-between' }}>
      {/* Left: logo + sidebar toggle */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        {sidebarCollapsed && (
          <button className="btn-ghost" onClick={onExpandSidebar} title="Show input panel">
            <PanelLeft size={18} />
          </button>
        )}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Globe size={20} color="var(--accent-primary)" />
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 600, color: 'var(--text-accent)' }}>
            Travel Planner
          </span>
        </div>
        {/* Backend status dot */}
        {backendStatus && (
          <span style={{ fontSize: 11, color: backendStatus.status === 'ok' ? 'var(--success)' : 'var(--error)', display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ fontSize: 8 }}>{backendStatus.status === 'ok' ? '●' : '●'}</span>
            {backendStatus.status === 'ok' ? 'Connected' : 'Backend offline'}
          </span>
        )}
      </div>

      {/* Center: tabs */}
      <div style={{ display: 'flex', gap: 2 }}>
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={`tab ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Right: actions */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {overview && (
          <button className="btn-secondary" onClick={handleExport} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px' }}>
            <Download size={14} />
            Export
          </button>
        )}
        <button
          className={`btn-ghost ${chatOpen ? 'active' : ''}`}
          onClick={() => setChatOpen(!chatOpen)}
          title="Toggle AI Chat"
          style={{ color: chatOpen ? 'var(--accent-primary)' : undefined }}
        >
          <MessageSquare size={18} />
        </button>
      </div>
    </div>
  );
}
