// ============================================================
// chat/ChatPanel.jsx — AI chatbox for follow-up questions
// ============================================================

import React, { useState, useRef, useEffect } from 'react';
import { Send, X, Bot, User, Loader } from 'lucide-react';
import { sendChatMessage } from '../../utils/api.js';

const QUICK_PROMPTS = [
  'Is this trip within budget?',
  'What are the visa requirements?',
  'Make this more offbeat',
  'Reduce cost by ₹50,000',
  'Add more food experiences',
  'Is it safe for solo travel?',
  'Best local dishes to try?',
  'Add a day trip option',
];

export default function ChatPanel({ overview, expandedDays, tripData, onClose }) {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: overview
        ? `Hi! I've reviewed your ${overview.tripSummary?.title || 'trip plan'}. Ask me anything — I can suggest changes, find cheaper options, add food spots, or answer any travel questions!`
        : `Hello! I'm your AI travel consultant. Generate a trip overview first, then I can help you refine it!`
    }
  ]);
  const [input, setInput] = useState('');
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Update welcome message when itinerary changes
  useEffect(() => {
    if (overview && messages.length === 1) {
      setMessages([{
        role: 'assistant',
        content: `✅ Your ${overview.tripSummary?.title || 'trip'} is ready! Total estimated: ₹${overview.budgetSummary?.grandTotalInr?.toLocaleString('en-IN') || '—'}. Ask me anything to refine it!`
      }]);
    }
  }, [overview]);

  const sendMessage = async (text) => {
    const userText = text || input.trim();
    if (!userText || isSending) return;

    const userMsg = { role: 'user', content: userText };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsSending(true);

    // Add typing indicator
    setMessages(prev => [...prev, { role: 'assistant', content: '...', isTyping: true }]);

    try {
      const chatHistory = messages.filter(m => !m.isTyping).slice(-8); // Last 8 msgs for context
      const result = await sendChatMessage(userText, { tripData, overview, expandedDays }, chatHistory);

      // Replace typing indicator with response
      setMessages(prev => [
        ...prev.filter(m => !m.isTyping),
        { role: 'assistant', content: result.reply }
      ]);
    } catch (err) {
      const errMsg = err?.response?.data?.error || err.message || 'Failed to get response';
      setMessages(prev => [
        ...prev.filter(m => !m.isTyping),
        { role: 'assistant', content: `Sorry, I hit an error: ${errMsg}`, isError: true }
      ]);
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="chat-panel">
      {/* Header */}
      <div className="topbar" style={{ justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'rgba(212,132,90,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Bot size={14} color="var(--accent-primary)" />
          </div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>Travel Assistant</div>
            <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>Powered by Claude</div>
          </div>
        </div>
        <button className="btn-ghost" onClick={onClose}><X size={16} /></button>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {messages.map((msg, i) => (
          <div key={i} style={{
            display: 'flex',
            gap: 8,
            flexDirection: msg.role === 'user' ? 'row-reverse' : 'row',
            alignItems: 'flex-start'
          }}>
            {/* Avatar */}
            <div style={{
              width: 24, height: 24, borderRadius: '50%', flexShrink: 0,
              background: msg.role === 'user' ? 'rgba(107,157,184,0.2)' : 'rgba(212,132,90,0.15)',
              display: 'flex', alignItems: 'center', justifyContent: 'center'
            }}>
              {msg.role === 'user'
                ? <User size={12} color="var(--accent-blue)" />
                : <Bot size={12} color="var(--accent-primary)" />
              }
            </div>

            {/* Bubble */}
            <div style={{
              maxWidth: '82%',
              padding: '9px 12px',
              borderRadius: msg.role === 'user' ? '12px 4px 12px 12px' : '4px 12px 12px 12px',
              background: msg.role === 'user' ? 'rgba(107,157,184,0.15)' : 'var(--bg-card)',
              border: `1px solid ${msg.role === 'user' ? 'rgba(107,157,184,0.2)' : 'var(--border-subtle)'}`,
              fontSize: 12.5,
              lineHeight: 1.6,
              color: msg.isError ? 'var(--error)' : 'var(--text-primary)',
              whiteSpace: 'pre-wrap'
            }}>
              {msg.isTyping ? (
                <div style={{ display: 'flex', gap: 4, alignItems: 'center', padding: '2px 0' }}>
                  {[0, 1, 2].map(j => (
                    <div key={j} style={{
                      width: 5, height: 5, borderRadius: '50%',
                      background: 'var(--text-muted)',
                      animation: 'pulse 1.2s ease-in-out infinite',
                      animationDelay: `${j * 0.2}s`
                    }} />
                  ))}
                </div>
              ) : msg.content}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick prompts */}
      <div style={{ padding: '8px 14px', borderTop: '1px solid var(--border-subtle)', overflowX: 'auto' }}>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'nowrap', paddingBottom: 4 }}>
          {QUICK_PROMPTS.map(prompt => (
            <button
              key={prompt}
              onClick={() => sendMessage(prompt)}
              disabled={isSending}
              style={{
                flexShrink: 0,
                padding: '4px 10px',
                borderRadius: 12,
                fontSize: 11,
                background: 'var(--bg-card)',
                color: 'var(--text-muted)',
                border: '1px solid var(--border-subtle)',
                cursor: 'pointer',
                whiteSpace: 'nowrap',
                transition: 'all 0.2s'
              }}
              onMouseEnter={e => { e.target.style.color = 'var(--accent-primary)'; e.target.style.borderColor = 'rgba(212,132,90,0.3)'; }}
              onMouseLeave={e => { e.target.style.color = 'var(--text-muted)'; e.target.style.borderColor = 'var(--border-subtle)'; }}
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div style={{ padding: '12px 14px', borderTop: '1px solid var(--border-subtle)', display: 'flex', gap: 8 }}>
        <textarea
          rows={2}
          placeholder="Ask anything about your trip..."
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isSending}
          style={{ flex: 1, resize: 'none', fontSize: 12.5, lineHeight: 1.5 }}
        />
        <button
          onClick={() => sendMessage()}
          disabled={isSending || !input.trim()}
          style={{
            padding: '8px 12px',
            borderRadius: 'var(--radius-sm)',
            background: input.trim() && !isSending ? 'var(--accent-primary)' : 'var(--bg-card)',
            color: input.trim() && !isSending ? 'white' : 'var(--text-muted)',
            border: 'none',
            cursor: input.trim() ? 'pointer' : 'default',
            transition: 'all 0.2s',
            alignSelf: 'flex-end'
          }}
        >
          {isSending ? <Loader size={14} style={{ animation: 'spin 1s linear infinite' }} /> : <Send size={14} />}
        </button>
      </div>
    </div>
  );
}
