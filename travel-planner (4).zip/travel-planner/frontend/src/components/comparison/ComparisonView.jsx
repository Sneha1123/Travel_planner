import React, { useState } from 'react';
import { formatInr, formatCurrency } from '../../utils/format.js';
import { ExternalLink, MapPin } from 'lucide-react';

export default function ComparisonView({ overview, tripData }) {
  const [activeSection, setActiveSection] = useState('destinations');
  const sections = [
    { id: 'destinations', label: '🗺️ Cities' },
    { id: 'flights', label: '✈️ Flights' },
    { id: 'hotels', label: '🏨 Hotels' },
    { id: 'transport', label: '🚆 Transport' },
  ];

  return (
    <div style={{ padding: '24px 28px', maxWidth: 960, margin: '0 auto' }}>
      <h2 style={{ fontSize: 20, marginBottom: 16 }}>🔍 Comparison View</h2>
      <div style={{ display: 'flex', gap: 6, marginBottom: 20, flexWrap: 'wrap' }}>
        {sections.map(s => (
          <button key={s.id} onClick={() => setActiveSection(s.id)}
            className={activeSection === s.id ? 'btn-secondary' : 'btn-ghost'} style={{ fontSize: 12 }}>
            {s.label}
          </button>
        ))}
      </div>

      {activeSection === 'destinations' && overview.cityPlan?.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 12 }}>
          {overview.cityPlan.map((dest, i) => (
            <div key={i} className="card" style={{ padding: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{dest.city}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{dest.country}</div>
                </div>
                <span className={`tag ${dest.costLevel === 'budget' ? 'tag-green' : dest.costLevel === 'expensive' ? 'tag-accent' : 'tag-gold'}`}>{dest.costLevel}</span>
              </div>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: 8 }}>{dest.whyVisit}</p>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 8 }}>
                {dest.bestFor?.map(tag => <span key={tag} className="tag tag-muted" style={{ fontSize: 10 }}>{tag}</span>)}
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                <span style={{ color: 'var(--text-muted)' }}>Nights:</span>
                <span style={{ fontWeight: 600 }}>{dest.nights}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginTop: 4 }}>
                <span style={{ color: 'var(--text-muted)' }}>Daily est.:</span>
                <span style={{ color: 'var(--accent-gold)', fontWeight: 600 }}>{formatInr(dest.estimatedDailyBudgetInr)}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeSection === 'flights' && (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                {['Route', 'Airlines', 'Duration', 'Stops', 'Price (INR)', 'Book'].map(h => (
                  <th key={h} style={{ padding: '8px 12px', textAlign: 'left', color: 'var(--text-muted)', fontWeight: 600, fontSize: 11 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { ...overview.flights?.outbound, label: 'Outbound' },
                { ...overview.flights?.return, label: 'Return' },
                ...(overview.flights?.intercity || []).map(f => ({ ...f, label: 'Intercity' }))
              ].filter(f => f.from).map((flight, i) => (
                <tr key={i} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                  <td style={{ padding: '10px 12px' }}>
                    <div style={{ fontWeight: 600 }}>{flight.from} → {flight.to}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{flight.label}</div>
                  </td>
                  <td style={{ padding: '10px 12px', color: 'var(--text-secondary)' }}>{flight.recommendedAirlines?.join(', ') || flight.mode || '—'}</td>
                  <td style={{ padding: '10px 12px', color: 'var(--text-secondary)' }}>{flight.duration}</td>
                  <td style={{ padding: '10px 12px' }}>
                    <span className={`tag ${flight.stops === 0 ? 'tag-green' : 'tag-muted'}`}>
                      {flight.stops === 0 ? 'Direct' : flight.stops != null ? `${flight.stops} stop(s)` : flight.mode || '—'}
                    </span>
                  </td>
                  <td style={{ padding: '10px 12px', fontFamily: 'var(--font-display)', color: 'var(--accent-gold)' }}>
                    {formatInr(flight.inrEquivalent)}
                    <div style={{ fontSize: 11, fontFamily: 'var(--font-ui)', color: 'var(--text-muted)' }}>{formatCurrency(flight.estimatedPrice, flight.currency)}</div>
                  </td>
                  <td style={{ padding: '10px 12px' }}>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      {flight.bookingLinks?.googleFlights && <a href={flight.bookingLinks.googleFlights} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: 'var(--accent-blue)', display: 'flex', alignItems: 'center', gap: 2 }}>Google <ExternalLink size={9} /></a>}
                      {flight.bookingLinks?.skyscanner && <a href={flight.bookingLinks.skyscanner} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: 'var(--accent-blue)', display: 'flex', alignItems: 'center', gap: 2 }}>Sky <ExternalLink size={9} /></a>}
                      {flight.bookingLink && <a href={flight.bookingLink} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: 'var(--accent-blue)', display: 'flex', alignItems: 'center', gap: 2 }}>Book <ExternalLink size={9} /></a>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeSection === 'hotels' && overview.hotels?.length > 0 && (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                {['City', 'Hotel', 'Stars', 'Area', 'Per Night', 'Total', 'Book'].map(h => (
                  <th key={h} style={{ padding: '8px 12px', textAlign: 'left', color: 'var(--text-muted)', fontWeight: 600, fontSize: 11 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {overview.hotels.map((hotel, i) => (
                <tr key={i} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                  <td style={{ padding: '10px 12px', color: 'var(--text-secondary)' }}>{hotel.city}</td>
                  <td style={{ padding: '10px 12px' }}><div style={{ fontWeight: 600 }}>{hotel.hotelName}</div><div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{hotel.type}</div></td>
                  <td style={{ padding: '10px 12px' }}>{'⭐'.repeat(hotel.stars || 4)}</td>
                  <td style={{ padding: '10px 12px', color: 'var(--text-muted)', fontSize: 12 }}>{hotel.area}</td>
                  <td style={{ padding: '10px 12px', fontFamily: 'var(--font-display)', color: 'var(--accent-gold)' }}>{formatInr(hotel.inrPerNight)}</td>
                  <td style={{ padding: '10px 12px', color: 'var(--text-secondary)' }}>{formatInr(hotel.totalInr)}</td>
                  <td style={{ padding: '10px 12px' }}>
                    <div style={{ display: 'flex', gap: 6 }}>
                      {hotel.bookingLinks?.booking && <a href={hotel.bookingLinks.booking} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: 'var(--accent-blue)', display: 'flex', alignItems: 'center', gap: 2 }}>Book <ExternalLink size={9} /></a>}
                      {hotel.mapsLink && <a href={hotel.mapsLink} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: 'var(--accent-secondary)', display: 'flex', alignItems: 'center', gap: 2 }}><MapPin size={9} /></a>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeSection === 'transport' && overview.flights?.intercity?.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 12 }}>
          {overview.flights.intercity.map((t, i) => (
            <div key={i} className="card" style={{ padding: 16 }}>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>{t.from} → {t.to}</div>
              <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                <span className="tag tag-blue">{t.mode}</span>
                <span className="tag tag-muted">{t.duration}</span>
              </div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, color: 'var(--accent-gold)', marginBottom: 4 }}>{formatInr(t.inrEquivalent)}</div>
              {t.tip && <p style={{ fontSize: 11, color: 'var(--text-muted)', fontStyle: 'italic', marginBottom: 8 }}>💡 {t.tip}</p>}
              {t.bookingLink && <a href={t.bookingLink} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: 'var(--accent-blue)', display: 'flex', alignItems: 'center', gap: 3 }}>Book <ExternalLink size={10} /></a>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
