// ============================================================
// routes/ai.js — All Claude AI API calls
// 2-step generation: overview first, then expand per day
// ============================================================

const express = require('express');
const router = express.Router();
const Anthropic = require('@anthropic-ai/sdk');

const getClient = () => {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key || key === 'your_anthropic_api_key_here') {
    throw new Error('ANTHROPIC_API_KEY not set in .env file');
  }
  return new Anthropic({ apiKey: key });
};

// ---- POST /api/ai/generate-overview ----
// Step 1: Fast trip overview — cities, nights, budget, flights, hotels
router.post('/generate-overview', async (req, res) => {
  try {
    const client = getClient();
    const { tripData, manualEntries } = req.body;
    if (!tripData) return res.status(400).json({ error: 'tripData is required' });

    const message = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 4000,
      messages: [{ role: 'user', content: buildOverviewPrompt(tripData, manualEntries || []) }]
    });

    const rawText = message.content[0].text;
    let overview;
    try {
      overview = extractJSON(rawText);
    } catch (parseErr) {
      console.error('Overview parse failed:', parseErr.message);
      console.error('Raw preview:', rawText.slice(0, 300));
      return res.json({ raw: rawText, parsed: false });
    }

    res.json({ overview, parsed: true, tokensUsed: message.usage });
  } catch (err) {
    console.error('Overview generate error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ---- POST /api/ai/expand-day ----
// Step 2: Expand a single day in full detail
router.post('/expand-day', async (req, res) => {
  try {
    const client = getClient();
    const { tripData, overview, dayNumber, cityName, date } = req.body;
    if (!dayNumber || !cityName) return res.status(400).json({ error: 'dayNumber and cityName are required' });

    const message = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 3000,
      messages: [{ role: 'user', content: buildDayPrompt(tripData, overview, dayNumber, cityName, date) }]
    });

    const rawText = message.content[0].text;
    let day;
    try {
      day = extractJSON(rawText);
    } catch (parseErr) {
      console.error('Day parse failed:', parseErr.message);
      return res.json({ raw: rawText, parsed: false });
    }

    res.json({ day, parsed: true, tokensUsed: message.usage });
  } catch (err) {
    console.error('Expand day error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ---- POST /api/ai/regenerate-day ----
// Regenerate a single day with optional user feedback
router.post('/regenerate-day', async (req, res) => {
  try {
    const client = getClient();
    const { tripData, overview, dayNumber, cityName, date, feedback } = req.body;

    let prompt = buildDayPrompt(tripData, overview, dayNumber, cityName, date);
    if (feedback) prompt += `\n\nUser feedback on previous plan: "${feedback}". Please adjust accordingly.`;

    const message = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 3000,
      messages: [{ role: 'user', content: prompt }]
    });

    const rawText = message.content[0].text;
    let day;
    try { day = extractJSON(rawText); }
    catch { return res.json({ raw: rawText, parsed: false }); }

    res.json({ day, parsed: true, tokensUsed: message.usage });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---- POST /api/ai/chat ----
router.post('/chat', async (req, res) => {
  try {
    const client = getClient();
    const { message, tripContext, chatHistory } = req.body;
    if (!message) return res.status(400).json({ error: 'message is required' });

    const messages = [
      {
        role: 'user',
        content: `You are an expert travel consultant. Trip context:\n${JSON.stringify(tripContext || {}, null, 2)}\n\nAnswer concisely with bullet points where helpful. Include prices in local currency and INR.`
      },
      { role: 'assistant', content: 'Understood! I have your full trip context. Ask me anything.' },
      ...(chatHistory || []).slice(-8).map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: message }
    ];

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages
    });

    res.json({ reply: response.content[0].text, tokensUsed: response.usage });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---- POST /api/ai/optimize-budget ----
router.post('/optimize-budget', async (req, res) => {
  try {
    const client = getClient();
    const { tripData, currentCost, targetBudget, currency } = req.body;

    const prompt = `You are a travel budget expert.
Trip: ${JSON.stringify(tripData, null, 2)}
Current cost: ${currentCost} ${currency}. Target: ${targetBudget} ${currency}. Gap: ${currentCost - targetBudget} ${currency}.
Return ONLY JSON:
{
  "summary": "brief explanation",
  "savingsNeeded": number,
  "optimizations": [{ "category": "flights|hotels|transport|activities|food", "action": "action", "currentCost": number, "newCost": number, "saving": number, "impact": "low|medium|high", "details": "details" }],
  "totalNewEstimate": number,
  "tips": ["tip1", "tip2", "tip3"]
}`;

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }]
    });

    let optimization;
    try { optimization = extractJSON(response.content[0].text); }
    catch { optimization = { raw: response.content[0].text }; }

    res.json({ optimization, tokensUsed: response.usage });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// PROMPT BUILDERS
// ============================================================

function buildOverviewPrompt(tripData, manualEntries = []) {
  // Build fixed cost section from manual entries
  const fixedFlights = manualEntries.filter(e => e.type === 'flight' || e.type === 'round_trip');
  const fixedHotels = manualEntries.filter(e => e.type === 'hotel');
  const fixedOther = manualEntries.filter(e => !['flight','round_trip','hotel'].includes(e.type));

  let fixedCostsSection = '';
  if (manualEntries.length > 0) {
    fixedCostsSection = `
FIXED COSTS (user has already found these — use EXACTLY these prices, do not estimate):
`;
    if (fixedFlights.length > 0) {
      fixedCostsSection += `\nFLIGHTS (FIXED — use these exact prices):\n`;
      fixedFlights.forEach(e => {
        fixedCostsSection += `- ${e.title}: ${e.currency} ${e.price} (₹${e.inrAmount || 'N/A'}) | Link: ${e.link}${e.returnLink ? ` | Return: ${e.returnLink}` : ''}${e.notes ? ` | Notes: ${e.notes}` : ''}\n`;
      });
    }
    if (fixedHotels.length > 0) {
      fixedCostsSection += `\nHOTELS (FIXED — use these exact prices):\n`;
      fixedHotels.forEach(e => {
        fixedCostsSection += `- ${e.title}: ${e.currency} ${e.price} (₹${e.inrAmount || 'N/A'}) | Link: ${e.link}${e.notes ? ` | Notes: ${e.notes}` : ''}\n`;
      });
    }
    if (fixedOther.length > 0) {
      fixedCostsSection += `\nOTHER FIXED COSTS:\n`;
      fixedOther.forEach(e => {
        fixedCostsSection += `- [${e.type}] ${e.title}: ${e.currency} ${e.price} (₹${e.inrAmount || 'N/A'})${e.notes ? ` | Notes: ${e.notes}` : ''}\n`;
      });
    }
    fixedCostsSection += `\nIMPORTANT: For any category above where the user has provided a fixed price, use EXACTLY that price in your budget calculations. Do not suggest alternatives for those categories.\n`;
  }

  return `You are an expert international travel planner. Create a trip OVERVIEW — city plan, flights, hotels, and budget summary. Do NOT generate day-by-day details yet.

TRIP REQUIREMENTS:
From: ${tripData.fromCity}, ${tripData.fromCountry}
To: ${tripData.toCountries?.join(', ')}
Dates: ${tripData.startDate} to ${tripData.endDate}
Total Days: ${tripData.numDays}
Travelers: ${tripData.travelers || 1}
Must-Visit: ${tripData.mustVisitPlaces?.join(', ') || 'None'}
Travel Style: ${tripData.travelStyle?.join(', ')}
Flight Class: ${tripData.flightClass}
Preferred Airlines: ${tripData.preferredAirlines || 'No preference'}
Avoid Airlines: ${tripData.avoidAirlines || 'None'}
Direct Only: ${tripData.directOnly ? 'Yes' : 'Okay with layovers'}
Hotel Vibe: ${tripData.hotelVibe}
Hotel Stars: ${tripData.hotelStars}
Hotel Budget/Night: ${tripData.hotelBudgetPerNight} ${tripData.currency}
Commute Prefs: ${tripData.commutePrefs?.join(', ')}
Total Budget: ${tripData.totalBudget} ${tripData.currency}
Currency: ${tripData.currency}
${fixedCostsSection}

Return ONLY this JSON (no markdown, start with {, end with }):
{
  "tripSummary": {
    "title": "Trip title",
    "description": "2 sentence overview",
    "highlights": ["highlight1", "highlight2", "highlight3"],
    "bestTimeToVisit": "Seasonal note",
    "weatherNote": "Weather summary"
  },
  "cityPlan": [
    {
      "city": "City name",
      "country": "Country",
      "nights": number,
      "arrivalDate": "YYYY-MM-DD",
      "departureDate": "YYYY-MM-DD",
      "days": [
        { "dayNumber": 1, "date": "YYYY-MM-DD", "theme": "Arrival & Old Town Exploration" }
      ],
      "whyVisit": "One sentence reason",
      "bestFor": ["culture", "food"],
      "costLevel": "budget|moderate|expensive",
      "estimatedDailyBudget": number,
      "estimatedDailyBudgetInr": number,
      "currency": "local currency code",
      "hiddenGems": [
        { "name": "Place", "description": "Why special", "type": "cafe|viewpoint|neighborhood|etc", "mapsLink": "https://www.google.com/maps/search/PlaceName+City", "cost": number, "inrCost": number }
      ]
    }
  ],
  "flights": {
    "outbound": {
      "from": "Origin city",
      "to": "First city",
      "estimatedPrice": number,
      "currency": "USD",
      "inrEquivalent": number,
      "duration": "9h 30m",
      "stops": number,
      "recommendedAirlines": ["airline1", "airline2"],
      "bookingLinks": {
        "googleFlights": "https://www.google.com/travel/flights",
        "skyscanner": "https://www.skyscanner.com",
        "makemytrip": "https://www.makemytrip.com/flights/"
      },
      "tip": "Booking tip"
    },
    "return": {
      "from": "Last city",
      "to": "Origin city",
      "estimatedPrice": number,
      "currency": "USD",
      "inrEquivalent": number,
      "duration": "9h 30m",
      "stops": number,
      "bookingLinks": {
        "googleFlights": "https://www.google.com/travel/flights",
        "skyscanner": "https://www.skyscanner.com"
      },
      "tip": "Booking tip"
    },
    "intercity": [
      {
        "from": "City A",
        "to": "City B",
        "mode": "train|bus|flight",
        "duration": "2h 30m",
        "estimatedPrice": number,
        "currency": "local",
        "inrEquivalent": number,
        "bookingLink": "URL",
        "tip": "Tip"
      }
    ]
  },
  "hotels": [
    {
      "city": "City",
      "hotelName": "Hotel Name",
      "type": "boutique|resort|hostel|etc",
      "stars": number,
      "pricePerNight": number,
      "currency": "local",
      "inrPerNight": number,
      "totalInr": number,
      "area": "Neighborhood",
      "whyRecommended": "One sentence",
      "bookingLinks": {
        "booking": "https://www.booking.com/searchresults.html?ss=CityName",
        "airbnb": "https://www.airbnb.com/s/CityName/homes",
        "googleHotels": "https://www.google.com/travel/hotels"
      },
      "mapsLink": "https://www.google.com/maps/search/HotelName+City"
    }
  ],
  "budgetSummary": {
    "currency": "USD",
    "exchangeRateToInr": number,
    "flights": { "total": number, "totalInr": number },
    "accommodation": { "total": number, "totalInr": number },
    "intercityTransport": { "total": number, "totalInr": number },
    "foodAndActivities": { "total": number, "totalInr": number },
    "buffer": { "total": number, "totalInr": number },
    "grandTotal": number,
    "grandTotalInr": number,
    "perDay": number,
    "perDayInr": number,
    "targetBudget": number,
    "isOverBudget": boolean,
    "budgetDifferenceInr": number
  },
  "usefulLinks": {
    "visaInfo": "URL",
    "weather": "URL",
    "currencyConverter": "https://www.xe.com/currencyconverter/",
    "travelInsurance": "https://www.coverfox.com/travel-insurance/"
  }
}`;
}

function buildDayPrompt(tripData, overview, dayNumber, cityName, date) {
  const cityInfo = overview?.cityPlan?.find(c => c.city === cityName);
  const dayInfo = cityInfo?.days?.find(d => d.dayNumber === dayNumber);
  const hotelArea = overview?.hotels?.find(h => h.city === cityName)?.area || 'city center';

  return `You are an expert travel planner. Generate FULL details for ONE specific day.

CONTEXT:
Traveler from: ${tripData.fromCity}, ${tripData.fromCountry}
Travel style: ${tripData.travelStyle?.join(', ')}
City: ${cityName}
Day: ${dayNumber}
Date: ${date}
Theme: ${dayInfo?.theme || 'City Exploration'}
Staying near: ${hotelArea}
Commute preferences: ${tripData.commutePrefs?.join(', ')}

Return ONLY this JSON (no markdown, start with {, end with }):
{
  "day": ${dayNumber},
  "date": "${date}",
  "city": "${cityName}",
  "theme": "${dayInfo?.theme || 'City Exploration'}",
  "morning": {
    "time": "9:00 AM",
    "activity": "Activity name",
    "description": "1-2 sentence description",
    "type": "sightseeing|food|transport|relaxation|adventure",
    "cost": number,
    "currency": "local",
    "inrCost": number,
    "duration": "2 hours",
    "bookingLink": null,
    "mapsLink": "https://www.google.com/maps/search/ActivityName+${cityName}",
    "tip": "Insider tip",
    "isOffbeat": false
  },
  "afternoon": {
    "time": "1:00 PM",
    "activity": "Activity name",
    "description": "1-2 sentence description",
    "type": "sightseeing|food|shopping|etc",
    "cost": number,
    "currency": "local",
    "inrCost": number,
    "duration": "3 hours",
    "bookingLink": null,
    "mapsLink": "https://www.google.com/maps/search/ActivityName+${cityName}",
    "tip": "Tip",
    "isOffbeat": false
  },
  "evening": {
    "time": "7:00 PM",
    "activity": "Activity name",
    "description": "1-2 sentence description",
    "type": "food|nightlife|sightseeing",
    "cost": number,
    "currency": "local",
    "inrCost": number,
    "duration": "2 hours",
    "bookingLink": null,
    "mapsLink": "https://www.google.com/maps/search/ActivityName+${cityName}",
    "tip": "Tip",
    "isOffbeat": false
  },
  "food": {
    "breakfast": { "place": "Name", "type": "cuisine type", "cost": number, "inrCost": number, "mapsLink": "https://www.google.com/maps/search/PlaceName+${cityName}" },
    "lunch": { "place": "Name", "type": "cuisine type", "cost": number, "inrCost": number, "mapsLink": "https://www.google.com/maps/search/PlaceName+${cityName}" },
    "dinner": { "place": "Name", "type": "cuisine type", "cost": number, "inrCost": number, "mapsLink": "https://www.google.com/maps/search/PlaceName+${cityName}" }
  },
  "localTransport": {
    "mode": "metro|taxi|walking|bus",
    "estimatedCost": number,
    "currency": "local",
    "inrCost": number,
    "tip": "Transport tip"
  },
  "totalDayCost": number,
  "totalDayCostInr": number,
  "notes": "Things to book in advance, warnings, tips"
}`;
}

// ---- Helper: Extract JSON robustly ----
function extractJSON(text) {
  if (!text) throw new Error('Empty response');
  const trimmed = text.trim();
  if (trimmed.startsWith('{')) return JSON.parse(trimmed);
  const jsonBlock = trimmed.match(/```json\s*([\s\S]*?)\s*```/);
  if (jsonBlock) return JSON.parse(jsonBlock[1].trim());
  const codeBlock = trimmed.match(/```\s*([\s\S]*?)\s*```/);
  if (codeBlock && codeBlock[1].trim().startsWith('{')) return JSON.parse(codeBlock[1].trim());
  const firstBrace = trimmed.indexOf('{');
  const lastBrace = trimmed.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) return JSON.parse(trimmed.slice(firstBrace, lastBrace + 1));
  throw new Error('No JSON found in response');
}

module.exports = router;
