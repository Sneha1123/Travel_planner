# 🌍 Smart Travel Planner

An AI-powered travel planning app that generates complete day-by-day itineraries with budget breakdowns, booking links, and an AI chatbox — all running locally on your Mac.

---

## ✨ What It Does

- **AI Itinerary Generation** — Claude AI creates a full day-by-day trip plan based on your preferences
- **Budget Breakdown** — KPI cards showing flights, hotels, food, activities — all in local currency + INR
- **Booking Links** — Direct links to Google Flights, Skyscanner, Booking.com, Airbnb, Google Maps
- **AI Chatbox** — Ask follow-up questions: "Make this cheaper", "Add food spots", "Is Prague worth it?"
- **Manual Links** — Paste your own found links + prices; saves to a local file in copy-paste format
- **Budget Optimizer** — Enter a lower budget target; Claude tells you what to cut
- **Comparison View** — Compare destinations, flights, hotels, transport options
- **Export** — Full trip saved as JSON, CSV (for Excel), and plain text

---

## 📁 Folder Structure

```
travel-planner/
│
├── package.json              ← Root: runs both frontend + backend together
├── setup.sh                  ← One-click Mac setup script
│
├── backend/                  ← Node.js/Express server
│   ├── server.js             ← Main server file
│   ├── .env                  ← Your API keys (YOU CREATE THIS)
│   ├── .env.example          ← Template for .env
│   ├── exports/              ← Your saved trip files appear here
│   └── routes/
│       ├── ai.js             ← All Claude AI API calls
│       ├── currency.js       ← Live exchange rates + INR conversion
│       ├── liveData.js       ← Live flights + hotels (when API keys set)
│       └── export.js         ← Save trip to local files
│
└── frontend/                 ← React app (Vite)
    ├── index.html
    ├── vite.config.js
    └── src/
        ├── App.jsx           ← Root component + global state
        ├── main.jsx          ← Entry point
        ├── utils/
        │   ├── api.js        ← All network calls to backend
        │   └── format.js     ← INR formatting, dates, etc.
        ├── styles/
        │   └── global.css    ← All styles + design system
        └── components/
            ├── MainContent.jsx
            ├── inputs/
            │   └── Sidebar.jsx       ← All trip input fields
            ├── itinerary/
            │   └── ItineraryView.jsx ← Day-by-day itinerary display
            ├── pricing/
            │   └── BudgetView.jsx    ← Budget KPI cards + optimizer
            ├── comparison/
            │   └── ComparisonView.jsx
            ├── chat/
            │   └── ChatPanel.jsx     ← AI chatbox
            └── shared/
                ├── Topbar.jsx
                ├── EmptyState.jsx
                ├── ManualEntryView.jsx ← Manual links + prices
                └── ApiKeysView.jsx     ← API key setup guide
```

---

## 🚀 First-Time Setup (Complete Beginner Guide)

### Step 1: Check if Node.js is installed

Open **Terminal** (press Cmd+Space, type "Terminal", press Enter).

Type this and press Enter:
```
node -v
```

If you see something like `v20.0.0` — you're good!

If you see "command not found":
1. Go to https://nodejs.org
2. Download the button that says **"LTS"** (Recommended For Most Users)
3. Open the downloaded file and install it
4. Close and reopen Terminal
5. Try `node -v` again

---

### Step 2: Download the project

If you received this as a ZIP file, unzip it. You should have a folder called `travel-planner`.

In Terminal, navigate to it:
```bash
cd ~/Downloads/travel-planner
# (adjust the path if you unzipped it somewhere else)
```

---

### Step 3: Run the setup script

```bash
bash setup.sh
```

This installs all required packages automatically. It takes 1–3 minutes.

---

### Step 4: Add your Anthropic API key

1. Open **Finder**
2. Navigate to the `travel-planner/backend/` folder
3. You'll see a file called `.env` (if it's hidden, press Cmd+Shift+. in Finder)
4. Open it in any text editor (TextEdit, VS Code, etc.)
5. Find this line:
   ```
   ANTHROPIC_API_KEY=your_anthropic_api_key_here
   ```
6. Replace `your_anthropic_api_key_here` with your actual key from https://console.anthropic.com/
7. Save the file

Your key looks like: `sk-ant-api03-...` (long string starting with sk-ant)

---

### Step 5: Start the app

```bash
npm run dev
```

You'll see both backend and frontend start. Wait until you see:
```
  VITE ready in Xms
  ➜  Local:   http://localhost:5173/
```

---

### Step 6: Open in browser

Go to: **http://localhost:5173**

---

## 🎯 How to Use

1. **Fill in Trip Details** — Use the left sidebar:
   - Trip Basics: where from, where to, dates, travelers, budget
   - Travel Style: offbeat, luxury, food, etc.
   - Flights: class, preferred airlines
   - Hotels: vibe, star rating, budget per night
   - Commute: train, flight, etc.

2. **Click "Generate Itinerary"** — Claude takes 15–30 seconds to plan your trip

3. **Explore the tabs:**
   - **Itinerary** — Full day-by-day plan with maps + booking links
   - **Budget** — KPI cards + breakdown + optimizer
   - **Compare** — Destinations, flights, hotels side by side
   - **My Links** — Paste your own found links + prices
   - **API Keys** — Guide to connect live data

4. **Use the Chat** — Ask follow-up questions in the right panel

5. **Export** — Click the Export button in the top bar to save everything

---

## 💰 Token Usage (What It Costs)

Every time you click "Generate Itinerary" or send a chat message, it uses Claude API tokens.

Approximate costs (Claude Sonnet pricing):
- **1 itinerary generation** ≈ 3,000–6,000 tokens ≈ **₹0.25–₹0.50**
- **1 chat message** ≈ 1,000–2,000 tokens ≈ **₹0.08–₹0.16**
- **Budget optimization** ≈ 2,000–3,000 tokens ≈ **₹0.16–₹0.25**

A full trip planning session (5–10 messages) costs roughly **₹2–₹5**.

---

## 🔌 Optional: Connect Live Prices

By default, the app uses AI-estimated prices. For live prices, go to the **API Keys** tab in the app for step-by-step instructions to connect:

| What | API | Cost | For |
|------|-----|------|-----|
| Live flights | Amadeus | Free tier | Real-time flight prices |
| Live hotels | RapidAPI/Booking | Free tier | Real hotel prices |
| Live exchange rates | ExchangeRate-API | Free tier | Accurate INR conversion |

---

## 🛑 Stopping the App

Press `Ctrl+C` in the Terminal window where `npm run dev` is running.

---

## 🔄 Starting Again Later

Every time you want to use the app:
```bash
cd ~/Downloads/travel-planner   # navigate to the folder
npm run dev                      # start the app
```

Then open http://localhost:5173 in your browser.

---

## ❓ Common Issues

**"Cannot connect to backend"**
- Make sure you ran `npm run dev` (not just started the frontend)
- Check that Terminal shows both backend (port 3001) and frontend (port 5173) running

**"ANTHROPIC_API_KEY not set"**
- Open `backend/.env` and make sure your key is there with no spaces
- Restart the server after editing .env

**"Generation Failed"**
- Check your Anthropic API credits at console.anthropic.com
- Make sure your key starts with `sk-ant-`

**Port already in use**
- Something is running on port 3001 or 5173
- Restart your computer, or change the PORT in backend/.env

---

## 🚀 Next Improvements (Ideas)

1. **Google Maps embed** — Show route on interactive map
2. **PDF export** — Beautiful formatted PDF of the itinerary
3. **Multiple trip storage** — Save and compare multiple trips
4. **Real-time flight tracker** — Live prices in a side panel
5. **WhatsApp share** — Share itinerary link with travel companions
6. **Offline mode** — Cache last generated trip for offline viewing
