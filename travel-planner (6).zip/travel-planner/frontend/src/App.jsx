// ============================================================
// App.jsx — Root component with full session persistence
// Auto-saves state to localStorage, restores on refresh
// ============================================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import Sidebar from './components/inputs/Sidebar.jsx';
import MainContent from './components/MainContent.jsx';
import ChatPanel from './components/chat/ChatPanel.jsx';
import Topbar from './components/shared/Topbar.jsx';
import SessionBanner from './components/shared/SessionBanner.jsx';
import { checkHealth } from './utils/api.js';
import { useChecklist } from './hooks/useChecklist.js';
import { useSession } from './hooks/useSession.js';

// Debounce — wait 1s after last change before saving
function debounce(fn, delay) {
  let timer;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
}

export default function App() {
  const { loadSession, saveSession, clearSession, saveChatHistory, loadChatHistory, getSessionMeta } = useSession();

  // ---- Trip input state ----
  const [tripData, setTripData] = useState({
    fromCity: '', fromCountry: 'India',
    toCountries: [], startDate: '', endDate: '',
    numDays: '', travelers: 1, mustVisitPlaces: [],
    travelStyle: [], flightClass: 'economy',
    preferredAirlines: '', avoidAirlines: '',
    directOnly: false, maxLayover: '',
    hotelVibe: '', hotelStars: 4, roomType: 'double',
    hotelBudgetPerNight: '', hotelAreas: '',
    commutePrefs: [], totalBudget: '', currency: 'INR',
  });

  const [overview, setOverview] = useState(null);
  const [expandedDays, setExpandedDays] = useState({});
  const [activeDayPanel, setActiveDayPanel] = useState(null);
  const [manualEntries, setManualEntries] = useState([]);
  const [priceOverrides, setPriceOverrides] = useState({});

  const [isGenerating, setIsGenerating] = useState(false);
  const [generateError, setGenerateError] = useState(null);
  const [activeTab, setActiveTab] = useState('itinerary');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [chatOpen, setChatOpen] = useState(true);
  const [backendStatus, setBackendStatus] = useState(null);

  // Session banner state
  const [sessionMeta, setSessionMeta] = useState(null);
  const [showRestoreBanner, setShowRestoreBanner] = useState(false);
  const [sessionRestored, setSessionRestored] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState(null);

  const checklist = useChecklist();
  const saveTimerRef = useRef(null);

  // ---- On mount: check for saved session ----
  useEffect(() => {
    checkHealth()
      .then(data => setBackendStatus(data))
      .catch(() => setBackendStatus({ status: 'error' }));

    const meta = getSessionMeta();
    if (meta?.hasOverview) {
      setSessionMeta(meta);
      setShowRestoreBanner(true);
    }
  }, []);

  // ---- Auto-save whenever key state changes ----
  const doSave = useCallback(
    debounce((data) => {
      saveSession(data);
      setLastSavedAt(new Date());
    }, 1000),
    [saveSession]
  );

  useEffect(() => {
    if (!overview && !manualEntries.length) return; // nothing to save yet
    doSave({ tripData, overview, expandedDays, manualEntries, priceOverrides, activeTab });
  }, [tripData, overview, expandedDays, manualEntries, priceOverrides, activeTab]);

  // ---- Restore session ----
  const handleRestoreSession = () => {
    const saved = loadSession();
    if (!saved) return;
    if (saved.tripData) setTripData(saved.tripData);
    if (saved.overview) setOverview(saved.overview);
    if (saved.expandedDays) setExpandedDays(saved.expandedDays);
    if (saved.manualEntries) setManualEntries(saved.manualEntries);
    if (saved.priceOverrides) setPriceOverrides(saved.priceOverrides);
    if (saved.activeTab) setActiveTab(saved.activeTab);
    setSessionRestored(true);
    setShowRestoreBanner(false);
  };

  // ---- Manual save (button) ----
  const handleManualSave = () => {
    saveSession({ tripData, overview, expandedDays, manualEntries, priceOverrides, activeTab });
    setLastSavedAt(new Date());
  };

  // ---- Clear session ----
  const handleClearSession = () => {
    if (window.confirm('Clear saved session? This cannot be undone.')) {
      clearSession();
      setSessionMeta(null);
      setLastSavedAt(null);
    }
  };

  // ---- New overview ----
  const handleNewOverview = (newOverview) => {
    setOverview(newOverview);
    setExpandedDays({});
    setActiveDayPanel(null);
    setPriceOverrides({});
  };

  return (
    <div className="app-layout">

      {/* Restore session banner */}
      {showRestoreBanner && sessionMeta && (
        <SessionBanner
          meta={sessionMeta}
          onRestore={handleRestoreSession}
          onDismiss={() => setShowRestoreBanner(false)}
        />
      )}

      {!sidebarCollapsed && (
        <Sidebar
          tripData={tripData}
          setTripData={setTripData}
          isGenerating={isGenerating}
          setIsGenerating={setIsGenerating}
          setOverview={handleNewOverview}
          setGenerateError={setGenerateError}
          onCollapse={() => setSidebarCollapsed(true)}
          manualEntries={manualEntries}
        />
      )}

      <div className="main-content">
        <Topbar
          overview={overview}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          backendStatus={backendStatus}
          sidebarCollapsed={sidebarCollapsed}
          onExpandSidebar={() => setSidebarCollapsed(false)}
          chatOpen={chatOpen}
          setChatOpen={setChatOpen}
          tripData={tripData}
          manualEntries={manualEntries}
          expandedDays={expandedDays}
          checklist={checklist}
          onManualSave={handleManualSave}
          onClearSession={handleClearSession}
          lastSavedAt={lastSavedAt}
        />
        <MainContent
          overview={overview}
          expandedDays={expandedDays}
          setExpandedDays={setExpandedDays}
          activeDayPanel={activeDayPanel}
          setActiveDayPanel={setActiveDayPanel}
          tripData={tripData}
          activeTab={activeTab}
          isGenerating={isGenerating}
          generateError={generateError}
          manualEntries={manualEntries}
          setManualEntries={setManualEntries}
          checklist={checklist}
          priceOverrides={priceOverrides}
          setPriceOverrides={setPriceOverrides}
        />
      </div>

      {chatOpen && (
        <ChatPanel
          overview={overview}
          expandedDays={expandedDays}
          tripData={tripData}
          onClose={() => setChatOpen(false)}
          onSaveChatHistory={saveChatHistory}
          savedChatHistory={loadChatHistory()}
        />
      )}
    </div>
  );
}
