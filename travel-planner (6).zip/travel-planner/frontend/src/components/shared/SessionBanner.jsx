// ============================================================
// shared/SessionBanner.jsx
// Shown on load when a saved session is found
// ============================================================

import React from 'react';
import { RotateCcw, X, Clock } from 'lucide-react';

export default function SessionBanner({ meta, onRestore, onDismiss }) {
  const savedTime = meta?.savedAt
    ? new Date(meta.savedAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
    : 'recently';

  return (
    <div style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 1000,
      background: 'linear-gradient(135deg, rgba(212,132,90,0.95), rgba(180,100,60,0.95))',
      backdropFilter: 'blur(8px)',
      padding: '12px 24px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      boxShadow: '0 2px 20px rgba(0,0,0,0.4)',
      flexWrap: 'wrap', gap: 10
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <Clock size={16} color="white" />
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'white' }}>
            Resume your trip — <span style={{ fontStyle: 'italic' }}>{meta.tripTitle}</span>
          </div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.8)' }}>
            {meta.cities && `${meta.cities} · `}
            {meta.expandedDays > 0 ? `${meta.expandedDays} day(s) planned · ` : ''}
            Saved {savedTime}
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button
          onClick={onRestore}
          style={{
            background: 'white', color: 'var(--accent-primary)',
            border: 'none', borderRadius: 8,
            padding: '8px 18px', fontSize: 13, fontWeight: 600,
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
            transition: 'all 0.2s'
          }}
        >
          <RotateCcw size={13} /> Restore Session
        </button>
        <button
          onClick={onDismiss}
          style={{
            background: 'rgba(255,255,255,0.2)', color: 'white',
            border: '1px solid rgba(255,255,255,0.3)', borderRadius: 8,
            padding: '8px 14px', fontSize: 13, cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 4
          }}
        >
          <X size={13} /> Start Fresh
        </button>
      </div>
    </div>
  );
}
