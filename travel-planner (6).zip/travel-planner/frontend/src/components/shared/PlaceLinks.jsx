// ============================================================
// shared/PlaceLinks.jsx
// Compact link buttons for any place — Maps, Search, Images
// Used everywhere a place name appears
// ============================================================

import React from 'react';
import { MapPin, Search, Image, ExternalLink } from 'lucide-react';
import { getPlaceLinks } from '../../utils/links.js';

// Size variants: 'sm' (default), 'xs'
export default function PlaceLinks({ name, city = '', mapsLink = null, size = 'sm', inline = false }) {
  if (!name) return null;
  const links = getPlaceLinks(name, city, mapsLink);

  const iconSize = size === 'xs' ? 9 : 10;
  const fontSize = size === 'xs' ? 10 : 11;
  const gap = inline ? 6 : 8;

  const btnStyle = {
    display: 'inline-flex', alignItems: 'center', gap: 3,
    fontSize, color: 'var(--accent-blue)',
    background: 'none', border: 'none', cursor: 'pointer',
    padding: 0, textDecoration: 'none', fontFamily: 'var(--font-ui)',
    transition: 'color 0.15s',
  };

  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap, flexWrap: 'wrap' }}>
      <a href={links.maps} target="_blank" rel="noreferrer" style={btnStyle} title={`Open ${name} in Google Maps`}>
        <MapPin size={iconSize} /> Maps
      </a>
      <a href={links.search} target="_blank" rel="noreferrer" style={{ ...btnStyle, color: 'var(--text-muted)' }} title={`Search ${name} on Google`}>
        <Search size={iconSize} /> Search
      </a>
      <a href={links.images} target="_blank" rel="noreferrer" style={{ ...btnStyle, color: 'var(--text-muted)' }} title={`See photos of ${name}`}>
        <Image size={iconSize} /> Photos
      </a>
    </span>
  );
}

// Minimal version — just the Maps icon, no label
export function MapsPinLink({ name, city = '', mapsLink = null, size = 10 }) {
  if (!name) return null;
  const { maps } = getPlaceLinks(name, city, mapsLink);
  return (
    <a href={maps} target="_blank" rel="noreferrer"
      style={{ display: 'inline-flex', alignItems: 'center', gap: 2, fontSize: 10, color: 'var(--accent-blue)', textDecoration: 'none' }}
      title={`Open in Google Maps`}>
      <MapPin size={size} /> Maps
    </a>
  );
}
