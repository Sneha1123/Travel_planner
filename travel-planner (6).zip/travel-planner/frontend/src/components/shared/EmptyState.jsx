// ============================================================
// shared/EmptyState.jsx — Shown when no itinerary generated yet
// ============================================================

import React from 'react';

export default function EmptyState() {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 40, textAlign: 'center' }}>
      {/* Globe illustration */}
      <div style={{ marginBottom: 28, position: 'relative' }}>
        <div style={{
          width: 100, height: 100, borderRadius: '50%',
          background: 'radial-gradient(circle at 35% 35%, rgba(212,132,90,0.3), rgba(107,157,184,0.2), rgba(143,181,160,0.1))',
          border: '1px solid rgba(212,132,90,0.2)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 44,
          boxShadow: '0 0 60px rgba(212,132,90,0.1)'
        }}>
          🌍
        </div>
      </div>

      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, marginBottom: 10, color: 'var(--text-accent)' }}>
        Where to next?
      </h2>
      <p style={{ fontSize: 14, color: 'var(--text-muted)', maxWidth: 400, lineHeight: 1.7, marginBottom: 28 }}>
        Fill in your trip details on the left — destinations, dates, travel style, and budget — then hit <strong style={{ color: 'var(--accent-primary)' }}>Generate Itinerary</strong>.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12, maxWidth: 480 }}>
        {[
          { icon: '🗓️', label: 'Day-by-day itinerary', desc: 'Morning, afternoon & evening plans' },
          { icon: '💰', label: 'Full budget breakdown', desc: 'Flights, hotels, food, activities' },
          { icon: '🏨', label: 'Hotel suggestions', desc: 'Matched to your vibe & budget' },
          { icon: '✈️', label: 'Flight options', desc: 'With booking links' },
          { icon: '🔭', label: 'Hidden gems', desc: 'Offbeat spots locals love' },
          { icon: '💬', label: 'AI chat assistant', desc: 'Ask anything, refine anything' },
        ].map(item => (
          <div key={item.label} style={{
            padding: '12px 16px', borderRadius: 'var(--radius-md)',
            background: 'var(--bg-card)', border: '1px solid var(--border-subtle)',
            textAlign: 'left'
          }}>
            <div style={{ fontSize: 20, marginBottom: 6 }}>{item.icon}</div>
            <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 2 }}>{item.label}</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{item.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
