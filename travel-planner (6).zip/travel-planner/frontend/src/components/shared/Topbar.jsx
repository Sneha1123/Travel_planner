// ============================================================
// shared/Topbar.jsx — Top navigation bar with save controls
// ============================================================

import React, { useState } from 'react';
import { PanelLeft, MessageSquare, Download, Globe, Save, Trash2, Check } from 'lucide-react';
import { exportTrip } from '../../utils/api.js';

export default function Topbar({
  overview, activeTab, setActiveTab, backendStatus,
  sidebarCollapsed, onExpandSidebar, chatOpen, setChatOpen,
  tripData, manualEntries, expandedDays, checklist,
  onManualSave, onClearSession, lastSavedAt
}) {
  const [justSaved, setJustSaved] = useState(false);

  const tabs = [
    { id: 'itinerary', label: 'Itinerary' },
    { id: 'budget', label: 'Budget' },
    { id: 'comparison', label: 'Compare' },
    { id: 'manual', label: 'My Links' },
    { id: 'settings', label: 'API Keys' },
  ];

  const handleExport = async () => {
    if (!overview) return alert('Generate a trip first!');
    try {
      const result = await exportTrip(tripData, overview, manualEntries);
      alert(`✅ Trip exported!\n\nFiles saved to:\n${result.files?.txt}`);
    } catch (err) {
      alert('Export failed: ' + err.message);
    }
  };

  const handleSave = () => {
    onManualSave();
    setJustSaved(true);
    setTimeout(() => setJustSaved(false), 2000);
  };

  const formatSavedTime = (date) => {
    if (!date) return null;
    return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="topbar" style={{ justifyContent: 'space-between' }}>
      {/* Left: logo + sidebar toggle + status */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        {sidebarCollapsed && (
          <button className="btn-ghost" onClick={onExpandSidebar} title="Show input panel">
            <PanelLeft size={18} />
          </button>
        )}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Globe size={20} color="var(--accent-primary)" />
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 600, color: 'var(--text-accent)' }}>
            Travel Planner
          </span>
        </div>
        {backendStatus && (
          <span style={{ fontSize: 11, color: backendStatus.status === 'ok' ? 'var(--success)' : 'var(--error)', display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ fontSize: 8 }}>●</span>
            {backendStatus.status === 'ok' ? 'Connected' : 'Backend offline'}
          </span>
        )}
        {/* Auto-save status */}
        {lastSavedAt && (
          <span style={{ fontSize: 10, color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 3 }}>
            <Check size={9} color="var(--success)" />
            Saved {formatSavedTime(lastSavedAt)}
          </span>
        )}
      </div>

      {/* Center: tabs */}
      <div style={{ display: 'flex', gap: 2 }}>
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={`tab ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Right: actions */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        {/* Save button */}
        <button
          className="btn-secondary"
          onClick={handleSave}
          title="Save session to browser storage"
          style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 12px', fontSize: 12,
            color: justSaved ? 'var(--success)' : undefined,
            borderColor: justSaved ? 'var(--success)' : undefined }}
        >
          {justSaved ? <Check size={13} /> : <Save size={13} />}
          {justSaved ? 'Saved!' : 'Save'}
        </button>

        {/* Export to file */}
        {overview && (
          <button className="btn-secondary" onClick={handleExport} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 12px', fontSize: 12 }}>
            <Download size={13} /> Export
          </button>
        )}

        {/* Clear session */}
        {overview && (
          <button
            className="btn-ghost"
            onClick={onClearSession}
            title="Clear saved session"
            style={{ color: 'var(--text-muted)', padding: '7px 8px' }}
          >
            <Trash2 size={14} />
          </button>
        )}

        {/* Chat toggle */}
        <button
          className="btn-ghost"
          onClick={() => setChatOpen(!chatOpen)}
          title="Toggle AI Chat"
          style={{ color: chatOpen ? 'var(--accent-primary)' : undefined }}
        >
          <MessageSquare size={18} />
        </button>
      </div>
    </div>
  );
}
