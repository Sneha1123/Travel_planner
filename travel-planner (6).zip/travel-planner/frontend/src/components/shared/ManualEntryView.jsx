// ============================================================
// shared/ManualEntryView.jsx
// Add links/prices manually; round-trip flight support
// These entries are injected into AI as fixed costs
// ============================================================

import React, { useState, useEffect } from 'react';
import { Plus, Copy, Download, Trash2, ExternalLink, Check, Send, RotateCcw } from 'lucide-react';
import { saveManualEntry, getManualEntries, exportTrip, sendWhatsApp } from '../../utils/api.js';
import { formatInr } from '../../utils/format.js';

const ENTRY_TYPES = [
  { id: 'round_trip', label: '✈️ Round Trip Flight' },
  { id: 'flight', label: '✈️ One-way Flight' },
  { id: 'hotel', label: '🏨 Hotel' },
  { id: 'train', label: '🚆 Train' },
  { id: 'bus', label: '🚌 Bus' },
  { id: 'activity', label: '🎭 Activity' },
  { id: 'restaurant', label: '🍽️ Restaurant' },
  { id: 'transfer', label: '🚐 Transfer' },
  { id: 'other', label: '📌 Other' },
];
const CURRENCIES = ['INR', 'USD', 'EUR', 'GBP', 'AED', 'SGD', 'THB', 'JPY', 'AUD'];

const EMPTY_FORM = {
  type: 'round_trip', title: '', link: '', returnLink: '', price: '',
  currency: 'INR', inrAmount: '', notes: '', category: ''
};

export default function ManualEntryView({ manualEntries, setManualEntries, overview, tripData }) {
  const [form, setForm] = useState(EMPTY_FORM);
  const [isSaving, setIsSaving] = useState(false);
  const [copied, setCopied] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [waNumber, setWaNumber] = useState(() => localStorage.getItem('wa_number') || '');
  const [waSending, setWaSending] = useState(false);
  const [waStatus, setWaStatus] = useState('');

  useEffect(() => {
    getManualEntries()
      .then(data => setManualEntries(data.entries || []))
      .catch(() => {});
  }, []);

  const updateForm = (key, value) => setForm(prev => ({ ...prev, [key]: value }));
  const isRoundTrip = form.type === 'round_trip';

  const handleSave = async () => {
    if (!form.title || !form.link) return alert('Title and outbound link are required');
    setIsSaving(true);
    try {
      const result = await saveManualEntry(form);
      setManualEntries(prev => [...prev, result.entry]);
      setForm(EMPTY_FORM);
      setShowForm(false);
    } catch (err) {
      alert('Failed to save: ' + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = (id) => setManualEntries(prev => prev.filter(e => e.id !== id));

  const copyAllText = () => {
    navigator.clipboard.writeText(generateCopyText(manualEntries)).then(() => {
      setCopied('all');
      setTimeout(() => setCopied(''), 2000);
    });
  };

  const handleWaNumber = (val) => {
    setWaNumber(val);
    localStorage.setItem('wa_number', val);
  };

  const sendToWhatsApp = async (text) => {
    if (!waNumber) return alert('Enter a WhatsApp number first (in the field below)');
    setWaSending(true);
    setWaStatus('');
    try {
      await sendWhatsApp(waNumber, text);
      setWaStatus('✅ Sent!');
    } catch (err) {
      // Fallback to wa.me quick share
      const encoded = encodeURIComponent(text);
      window.open(`https://wa.me/${waNumber.replace(/\D/g,'')}?text=${encoded}`, '_blank');
      setWaStatus('📱 Opened WhatsApp');
    } finally {
      setWaSending(false);
      setTimeout(() => setWaStatus(''), 3000);
    }
  };

  const sendEntriesToWhatsApp = () => sendToWhatsApp(generateCopyText(manualEntries));

  return (
    <div style={{ padding: '24px 28px', maxWidth: 900, margin: '0 auto' }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h2 style={{ fontSize: 20, marginBottom: 4 }}>📌 My Links & Prices</h2>
          <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>
            Entries here are used as <strong style={{ color: 'var(--accent-primary)' }}>fixed costs</strong> when generating your itinerary — Claude won't estimate, it uses your prices.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button className="btn-secondary" onClick={copyAllText} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12 }}>
            {copied === 'all' ? <Check size={13} /> : <Copy size={13} />}
            {copied === 'all' ? 'Copied!' : 'Copy All'}
          </button>
          <button className="btn-primary" onClick={() => setShowForm(!showForm)} style={{ display: 'flex', alignItems: 'center', gap: 6, width: 'auto', padding: '9px 16px', fontSize: 12 }}>
            <Plus size={13} /> Add Entry
          </button>
        </div>
      </div>

      {/* WhatsApp number input */}
      <div className="card" style={{ marginBottom: 16, padding: 14, borderColor: 'rgba(143,181,160,0.2)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 12, color: 'var(--text-secondary)', flexShrink: 0 }}>📱 WhatsApp number:</span>
          <input
            placeholder="+91 98765 43210 (with country code)"
            value={waNumber}
            onChange={e => handleWaNumber(e.target.value)}
            style={{ flex: 1, minWidth: 200, fontSize: 12 }}
          />
          {waStatus && <span style={{ fontSize: 12, color: 'var(--success)' }}>{waStatus}</span>}
        </div>
        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 6 }}>
          Used for all "Send to WhatsApp" buttons. Saved automatically.
        </p>
      </div>

      {/* Add form */}
      {showForm && (
        <div className="card" style={{ marginBottom: 20, borderColor: 'rgba(212,132,90,0.2)' }}>
          <h3 style={{ fontSize: 14, marginBottom: 14 }}>Add New Entry</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
            <div>
              <div className="section-label">Type</div>
              <select value={form.type} onChange={e => updateForm('type', e.target.value)}>
                {ENTRY_TYPES.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
              </select>
            </div>
            <div>
              <div className="section-label">Title / Description *</div>
              <input placeholder={isRoundTrip ? 'e.g. Emirates Chennai–Amsterdam round trip' : 'e.g. Park Hotel Amsterdam'} value={form.title} onChange={e => updateForm('title', e.target.value)} />
            </div>
          </div>

          <div style={{ marginBottom: 12 }}>
            <div className="section-label">{isRoundTrip ? 'Outbound Link *' : 'Link / URL *'}</div>
            <input placeholder="Paste the booking link here" value={form.link} onChange={e => updateForm('link', e.target.value)} />
          </div>

          {/* Return link — only for round trips */}
          {isRoundTrip && (
            <div style={{ marginBottom: 12 }}>
              <div className="section-label">Return Link (optional)</div>
              <input placeholder="Paste the return flight link here" value={form.returnLink} onChange={e => updateForm('returnLink', e.target.value)} />
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginBottom: 12 }}>
            <div>
              <div className="section-label">{isRoundTrip ? 'Total Price (both ways)' : 'Price'}</div>
              <input type="number" placeholder="e.g. 45000" value={form.price} onChange={e => updateForm('price', e.target.value)} />
            </div>
            <div>
              <div className="section-label">Currency</div>
              <select value={form.currency} onChange={e => updateForm('currency', e.target.value)}>
                {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <div className="section-label">INR Equivalent</div>
              <input type="number" placeholder="₹ amount" value={form.inrAmount} onChange={e => updateForm('inrAmount', e.target.value)} />
            </div>
          </div>

          <div style={{ marginBottom: 14 }}>
            <div className="section-label">Notes</div>
            <textarea rows={2} placeholder="e.g. 2 adults, includes baggage, flexible dates..." value={form.notes} onChange={e => updateForm('notes', e.target.value)} />
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn-primary" onClick={handleSave} disabled={isSaving} style={{ width: 'auto', padding: '9px 20px' }}>
              {isSaving ? 'Saving...' : 'Save Entry'}
            </button>
            <button className="btn-secondary" onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </div>
      )}

      {/* Regeneration note */}
      {manualEntries.length > 0 && (
        <div style={{ padding: '10px 14px', background: 'rgba(212,132,90,0.08)', border: '1px solid rgba(212,132,90,0.2)', borderRadius: 'var(--radius-md)', marginBottom: 16, fontSize: 12, color: 'var(--text-secondary)' }}>
          💡 <strong>Tip:</strong> After adding entries here, re-generate your itinerary — Claude will use these exact prices instead of estimating.
        </div>
      )}

      {/* Entries list */}
      {manualEntries.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: 40 }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>📋</div>
          <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No entries yet. Add your real flight/hotel links with prices here.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {manualEntries.map((entry, i) => (
            <EntryCard
              key={entry.id || i}
              entry={entry}
              onDelete={() => handleDelete(entry.id || i)}
              onSendWa={() => sendToWhatsApp(entryToText(entry))}
              waSending={waSending}
            />
          ))}
        </div>
      )}

      {/* Copy-paste + WhatsApp section */}
      {manualEntries.length > 0 && (
        <div className="card" style={{ marginTop: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, flexWrap: 'wrap', gap: 8 }}>
            <h3 style={{ fontSize: 14 }}>📋 Copy-Paste Format</h3>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn-secondary" onClick={copyAllText} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11 }}>
                {copied === 'all' ? <Check size={12} /> : <Copy size={12} />}
                {copied === 'all' ? 'Copied!' : 'Copy'}
              </button>
              <button className="btn-secondary" onClick={sendEntriesToWhatsApp} disabled={waSending} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: 'var(--accent-secondary)' }}>
                <Send size={12} /> Send to WhatsApp
              </button>
            </div>
          </div>
          <pre style={{ whiteSpace: 'pre-wrap', fontSize: 11, color: 'var(--text-secondary)', lineHeight: 1.7, background: 'var(--bg-input)', padding: 14, borderRadius: 'var(--radius-sm)', maxHeight: 300, overflowY: 'auto' }}>
            {generateCopyText(manualEntries)}
          </pre>
        </div>
      )}
    </div>
  );
}

function EntryCard({ entry, onDelete, onSendWa, waSending }) {
  const typeLabel = ENTRY_TYPES.find(t => t.id === entry.type)?.label || entry.type;
  return (
    <div className="card" style={{ padding: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div style={{ flex: 1, marginRight: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5, flexWrap: 'wrap' }}>
            <span className="tag tag-muted" style={{ fontSize: 10 }}>{typeLabel}</span>
            <span style={{ fontWeight: 600, fontSize: 13 }}>{entry.title}</span>
          </div>
          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginBottom: 5 }}>
            {entry.price && (
              <span style={{ fontSize: 13, color: 'var(--accent-gold)', fontWeight: 600 }}>
                {entry.currency} {entry.price}
                {entry.inrAmount ? ` (${formatInr(entry.inrAmount)})` : ''}
              </span>
            )}
          </div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 4 }}>
            <a href={entry.link} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: 'var(--accent-blue)', display: 'flex', alignItems: 'center', gap: 2 }}>
              {entry.type === 'round_trip' ? 'Outbound' : 'Link'} <ExternalLink size={9} />
            </a>
            {entry.returnLink && (
              <a href={entry.returnLink} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: 'var(--accent-blue)', display: 'flex', alignItems: 'center', gap: 2 }}>
                Return <ExternalLink size={9} />
              </a>
            )}
          </div>
          {entry.notes && <p style={{ fontSize: 11, color: 'var(--text-muted)', fontStyle: 'italic' }}>{entry.notes}</p>}
        </div>
        <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
          <button onClick={onSendWa} disabled={waSending} className="btn-ghost" title="Send to WhatsApp" style={{ color: 'var(--accent-secondary)', padding: '4px 6px' }}>
            <Send size={13} />
          </button>
          <button onClick={onDelete} className="btn-ghost" style={{ color: 'var(--error)', padding: '4px 6px' }}>
            <Trash2 size={13} />
          </button>
        </div>
      </div>
    </div>
  );
}

function entryToText(entry) {
  const typeLabel = ENTRY_TYPES.find(t => t.id === entry.type)?.label || entry.type;
  let text = `${typeLabel}: ${entry.title}\n`;
  if (entry.price) text += `Price: ${entry.currency} ${entry.price}${entry.inrAmount ? ` (₹${parseInt(entry.inrAmount).toLocaleString('en-IN')})` : ''}\n`;
  text += `Link: ${entry.link}\n`;
  if (entry.returnLink) text += `Return: ${entry.returnLink}\n`;
  if (entry.notes) text += `Notes: ${entry.notes}\n`;
  return text;
}

function generateCopyText(entries) {
  if (!entries.length) return 'No entries yet.';
  return [
    '==========================================',
    '📌 MY TRAVEL LINKS & PRICES',
    `Generated: ${new Date().toLocaleString('en-IN')}`,
    '==========================================',
    '',
    ...entries.map((e, i) => entryToText(e)),
  ].join('\n');
}
