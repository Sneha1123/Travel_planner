// ============================================================
// shared/ApiKeysView.jsx — Guide to setting up API keys
// ============================================================

import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, ExternalLink, Copy, Check } from 'lucide-react';
import { checkHealth } from '../../utils/api.js';

export default function ApiKeysView() {
  const [status, setStatus] = useState(null);
  const [copied, setCopied] = useState('');

  useEffect(() => {
    checkHealth().then(setStatus).catch(() => setStatus({ status: 'error' }));
  }, []);

  const copyText = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(''), 2000);
  };

  const apis = [
    {
      key: 'ANTHROPIC_API_KEY',
      name: 'Anthropic (Claude AI)',
      required: true,
      status: status?.apis?.anthropic,
      description: 'Powers itinerary generation and the chatbox. Required.',
      url: 'https://console.anthropic.com/',
      steps: ['Go to console.anthropic.com', 'Create account → API Keys', 'Copy key', 'Paste in backend/.env']
    },
    {
      key: 'AMADEUS_API_KEY',
      name: 'Amadeus Flights',
      required: false,
      status: status?.apis?.amadeus,
      description: 'Live flight prices and availability. Free tier available.',
      url: 'https://developers.amadeus.com/',
      steps: ['Go to developers.amadeus.com', 'Create free account', 'Create new app → get API key + secret', 'Add both keys to backend/.env']
    },
    {
      key: 'RAPIDAPI_KEY',
      name: 'RapidAPI (Hotels)',
      required: false,
      status: status?.apis?.rapidapi,
      description: 'Live hotel prices via Booking.com on RapidAPI.',
      url: 'https://rapidapi.com/booking/api/booking',
      steps: ['Go to rapidapi.com', 'Subscribe to Booking.com API (free tier)', 'Copy X-RapidAPI-Key', 'Add as RAPIDAPI_KEY in backend/.env']
    },
    {
      key: 'EXCHANGE_RATE_API_KEY',
      name: 'Exchange Rate API',
      required: false,
      status: status?.apis?.exchangeRate,
      description: 'Live currency rates for accurate INR conversion.',
      url: 'https://app.exchangerate-api.com/',
      steps: ['Go to exchangerate-api.com', 'Sign up free (1500 requests/month)', 'Copy API key', 'Add as EXCHANGE_RATE_API_KEY in backend/.env']
    },
    {
      key: 'WHATSAPP_PHONE_NUMBER_ID + WHATSAPP_TOKEN',
      name: 'WhatsApp Cloud API (Meta)',
      required: false,
      status: status?.apis?.whatsapp,
      description: 'Send day plans and itineraries directly to a WhatsApp number or group.',
      url: 'https://developers.facebook.com/',
      steps: [
        'Go to developers.facebook.com → Create App → Business type',
        'Add "WhatsApp" product to your app',
        'Under WhatsApp → Getting Started, copy the "Phone Number ID"',
        'Copy the temporary "Access Token" (or generate a permanent one)',
        'Add both to backend/.env as WHATSAPP_PHONE_NUMBER_ID and WHATSAPP_TOKEN',
        'Set WHATSAPP_RECIPIENT_NUMBER to your number with country code (e.g. 919876543210)',
        'Note: Free tier allows sending to verified test numbers only'
      ]
    },
  ];

  return (
    <div style={{ padding: '24px 28px', maxWidth: 800, margin: '0 auto' }}>
      <h2 style={{ fontSize: 20, marginBottom: 6 }}>⚙️ API Keys Setup</h2>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 24 }}>
        Configure API keys to enable live prices. All keys go in the file: <code style={{ background: 'var(--bg-card)', padding: '2px 6px', borderRadius: 4, fontSize: 12 }}>backend/.env</code>
      </p>

      {/* .env file template */}
      <div className="card" style={{ marginBottom: 24, borderColor: 'rgba(201,169,110,0.2)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <h3 style={{ fontSize: 14 }}>📄 backend/.env template</h3>
          <button
            className="btn-secondary"
            onClick={() => copyText(ENV_TEMPLATE, 'env')}
            style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11 }}
          >
            {copied === 'env' ? <Check size={12} /> : <Copy size={12} />}
            {copied === 'env' ? 'Copied!' : 'Copy'}
          </button>
        </div>
        <pre style={{ fontSize: 11.5, color: 'var(--text-secondary)', lineHeight: 1.7, background: 'var(--bg-input)', padding: 14, borderRadius: 'var(--radius-sm)', overflowX: 'auto' }}>
{ENV_TEMPLATE}
        </pre>
      </div>

      {/* API cards */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {apis.map(api => (
          <div key={api.key} className="card" style={{ borderColor: api.required && !api.status ? 'rgba(212,132,90,0.3)' : 'var(--border-subtle)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span style={{ fontWeight: 600, fontSize: 14 }}>{api.name}</span>
                  {api.required && <span className="tag tag-accent" style={{ fontSize: 10 }}>Required</span>}
                  {!api.required && <span className="tag tag-muted" style={{ fontSize: 10 }}>Optional</span>}
                </div>
                <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>{api.description}</p>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                {api.status === undefined ? (
                  <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>checking...</span>
                ) : api.status ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: 'var(--success)', fontSize: 12 }}>
                    <CheckCircle size={14} /> Connected
                  </div>
                ) : (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: 'var(--text-muted)', fontSize: 12 }}>
                    <XCircle size={14} /> Not set
                  </div>
                )}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', marginBottom: 6, letterSpacing: '0.06em' }}>SETUP STEPS</div>
                {api.steps.map((step, i) => (
                  <div key={i} style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 3, display: 'flex', gap: 8 }}>
                    <span style={{ color: 'var(--accent-primary)', fontWeight: 600, flexShrink: 0 }}>{i + 1}.</span>
                    {step}
                  </div>
                ))}
              </div>
              <a
                href={api.url}
                target="_blank"
                rel="noreferrer"
                className="btn-secondary"
                style={{ display: 'flex', alignItems: 'center', gap: 6, textDecoration: 'none', fontSize: 12, flexShrink: 0, marginTop: 18 }}
              >
                Get Key <ExternalLink size={11} />
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Restart note */}
      <div style={{ marginTop: 20, padding: 14, background: 'rgba(201,169,110,0.08)', border: '1px solid rgba(201,169,110,0.2)', borderRadius: 'var(--radius-md)' }}>
        <p style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
          💡 <strong>After editing backend/.env</strong>, stop the backend server (Ctrl+C in Terminal) and restart it with <code style={{ background: 'var(--bg-card)', padding: '1px 5px', borderRadius: 3, fontSize: 11 }}>npm run dev</code> from the <code style={{ background: 'var(--bg-card)', padding: '1px 5px', borderRadius: 3, fontSize: 11 }}>backend/</code> folder for keys to take effect.
        </p>
      </div>
    </div>
  );
}

const ENV_TEMPLATE = `# Required
ANTHROPIC_API_KEY=sk-ant-...your-key-here...

# Optional: Live Flights
AMADEUS_API_KEY=
AMADEUS_API_SECRET=

# Optional: Live Hotels
RAPIDAPI_KEY=
BOOKING_RAPIDAPI_KEY=

# Optional: Currency Rates
EXCHANGE_RATE_API_KEY=

# Optional: WhatsApp Cloud API
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_TOKEN=
WHATSAPP_RECIPIENT_NUMBER=

# Server
PORT=3001`;
