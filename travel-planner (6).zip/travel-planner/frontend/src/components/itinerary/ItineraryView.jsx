// ============================================================
// itinerary/ItineraryView.jsx
// Left: overview + day cards
// Right: day detail panel with checkboxes, editable prices, WA send
// ============================================================

import React, { useState } from 'react';
import { MapPin, ExternalLink, Star, ChevronRight, RefreshCw, X,
  Utensils, Train, Plane, Sparkles, Check, Send, Copy,
  Pencil, CheckSquare, Square, RotateCcw } from 'lucide-react';
import { expandDay, regenerateDay } from '../../utils/api.js';
import { formatInr, formatCurrency } from '../../utils/format.js';
import { sendToWhatsApp, formatDayForWhatsApp, formatOverviewForWhatsApp } from '../../utils/whatsapp.js';
import PlaceLinks, { MapsPinLink } from '../shared/PlaceLinks.jsx';
import { ensureMapsLink } from '../../utils/links.js';

export default function ItineraryView({ overview, expandedDays, setExpandedDays, activeDayPanel, setActiveDayPanel, tripData, checklist, priceOverrides, setPriceOverrides }) {
  const [loadingDays, setLoadingDays] = useState({});
  const [expandAllLoading, setExpandAllLoading] = useState(false);
  const [waStatus, setWaStatus] = useState('');
  const [showChecklistPanel, setShowChecklistPanel] = useState(false);
  const [restoreText, setRestoreText] = useState('');

  const totalDays = overview?.cityPlan?.reduce((sum, c) => sum + (c.days?.length || 0), 0) || 0;
  const expandedCount = Object.keys(expandedDays).length;

  const setPrice = (key, value) => setPriceOverrides(prev => ({ ...prev, [key]: parseFloat(value) || 0 }));
  const getPrice = (key, fallback) => priceOverrides[key] !== undefined ? priceOverrides[key] : (fallback || 0);

  const handleExpandDay = async (dayNumber, cityName, date) => {
    if (expandedDays[dayNumber]) {
      setActiveDayPanel({ dayNumber, cityName, date });
      return;
    }
    setLoadingDays(prev => ({ ...prev, [dayNumber]: true }));
    try {
      const result = await expandDay(tripData, overview, dayNumber, cityName, date);
      if (result.parsed && result.day) {
        setExpandedDays(prev => ({ ...prev, [dayNumber]: result.day }));
        setActiveDayPanel({ dayNumber, cityName, date });
      }
    } catch (err) {
      alert('Failed to expand day: ' + (err?.response?.data?.error || err.message));
    } finally {
      setLoadingDays(prev => ({ ...prev, [dayNumber]: false }));
    }
  };

  const handleExpandAll = async () => {
    setExpandAllLoading(true);
    const allDays = overview?.cityPlan?.flatMap(city =>
      city.days?.map(d => ({ dayNumber: d.dayNumber, cityName: city.city, date: d.date })) || []
    ) || [];
    await Promise.all(
      allDays.filter(d => !expandedDays[d.dayNumber]).map(async ({ dayNumber, cityName, date }) => {
        try {
          const result = await expandDay(tripData, overview, dayNumber, cityName, date);
          if (result.parsed && result.day) setExpandedDays(prev => ({ ...prev, [dayNumber]: result.day }));
        } catch {}
      })
    );
    setExpandAllLoading(false);
  };

  const handleRegenerate = async (dayNumber, cityName, date, feedback) => {
    setLoadingDays(prev => ({ ...prev, [dayNumber]: true }));
    // Build must-keep context from checklist
    const mustKeep = checklist.getCheckedForDay(dayNumber);
    const mustKeepText = mustKeep.length
      ? `\nMUST KEEP (user marked these as must-do, do not remove them): ${mustKeep.map(i => `${i.slot}: ${i.label}`).join(', ')}`
      : '';
    try {
      const result = await regenerateDay(tripData, overview, dayNumber, cityName, date, (feedback || '') + mustKeepText);
      if (result.parsed && result.day) setExpandedDays(prev => ({ ...prev, [dayNumber]: result.day }));
    } catch (err) {
      alert('Failed to regenerate: ' + (err?.response?.data?.error || err.message));
    } finally {
      setLoadingDays(prev => ({ ...prev, [dayNumber]: false }));
    }
  };

  const handleSendOverview = async () => {
    try {
      const text = formatOverviewForWhatsApp(overview, expandedDays);
      const result = await sendToWhatsApp(text);
      setWaStatus(result.method === 'api' ? '✅ Sent!' : '📱 Opened WhatsApp');
      setTimeout(() => setWaStatus(''), 3000);
    } catch (err) {
      alert(err.message);
    }
  };

  const handleRestoreChecklist = () => {
    const count = checklist.restoreFromText(restoreText);
    alert(`✅ Restored ${count} checked item(s)`);
    setRestoreText('');
    setShowChecklistPanel(false);
  };

  return (
    <div style={{ display: 'flex', height: '100%', overflow: 'hidden' }}>

      {/* ---- LEFT: Overview ---- */}
      <div style={{ flex: activeDayPanel ? '0 0 420px' : 1, overflowY: 'auto', padding: '20px 20px', borderRight: activeDayPanel ? '1px solid var(--border-subtle)' : 'none', transition: 'flex 0.3s ease' }}>

        {/* Trip header */}
        <TripHeader overview={overview} />

        {/* Top actions */}
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16, alignItems: 'center' }}>
          <button className="btn-secondary" onClick={handleExpandAll} disabled={expandAllLoading || expandedCount === totalDays}
            style={{ fontSize: 11, padding: '6px 12px', display: 'flex', alignItems: 'center', gap: 5 }}>
            {expandAllLoading ? <><span className="spinner" style={{ width: 12, height: 12 }} /> Expanding...</>
              : expandedCount === totalDays ? <><Check size={12} /> All expanded</>
              : <><Sparkles size={12} /> Expand All Days</>}
          </button>
          <button className="btn-secondary" onClick={handleSendOverview}
            style={{ fontSize: 11, padding: '6px 12px', display: 'flex', alignItems: 'center', gap: 5, color: 'var(--accent-secondary)' }}>
            <Send size={12} /> Send Overview to WhatsApp
          </button>
          <button className="btn-secondary" onClick={() => setShowChecklistPanel(!showChecklistPanel)}
            style={{ fontSize: 11, padding: '6px 12px', display: 'flex', alignItems: 'center', gap: 5 }}>
            <CheckSquare size={12} /> Must-Do ({checklist.count})
          </button>
          {waStatus && <span style={{ fontSize: 11, color: 'var(--success)' }}>{waStatus}</span>}
        </div>

        {/* Checklist panel */}
        {showChecklistPanel && (
          <ChecklistPanel checklist={checklist} restoreText={restoreText} setRestoreText={setRestoreText} onRestore={handleRestoreChecklist} onClose={() => setShowChecklistPanel(false)} />
        )}

        {/* Flights — with editable prices */}
        {overview.flights && <FlightsSummary flights={overview.flights} priceOverrides={priceOverrides} setPrice={setPrice} />}

        {/* Hotels — with editable prices */}
        {overview.hotels?.length > 0 && <HotelsSummary hotels={overview.hotels} priceOverrides={priceOverrides} setPrice={setPrice} cityPlan={overview.cityPlan} />}

        {/* City plan + day cards */}
        <div style={{ marginTop: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <h2 style={{ fontSize: 16 }}>📅 Day Plan</h2>
            <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{expandedCount}/{totalDays} expanded</span>
          </div>
          {overview.cityPlan?.map(city => (
            <CitySection key={city.city} city={city} expandedDays={expandedDays} loadingDays={loadingDays}
              activeDayPanel={activeDayPanel} onExpandDay={handleExpandDay} />
          ))}
        </div>

        {/* Hidden gems */}
        {overview.cityPlan?.some(c => c.hiddenGems?.length) && <HiddenGems cityPlan={overview.cityPlan} checklist={checklist} />}

        {/* Useful links */}
        {overview.usefulLinks && <UsefulLinks links={overview.usefulLinks} />}
      </div>

      {/* ---- RIGHT: Day detail panel ---- */}
      {activeDayPanel && (
        <DayPanel
          dayData={expandedDays[activeDayPanel.dayNumber]}
          dayInfo={activeDayPanel}
          isLoading={loadingDays[activeDayPanel.dayNumber]}
          onClose={() => setActiveDayPanel(null)}
          onRegenerate={(feedback) => handleRegenerate(activeDayPanel.dayNumber, activeDayPanel.cityName, activeDayPanel.date, feedback)}
          checklist={checklist}
          priceOverrides={priceOverrides}
          setPrice={setPrice}
          overview={overview}
        />
      )}
    </div>
  );
}

// ---- Checklist panel ----
function ChecklistPanel({ checklist, restoreText, setRestoreText, onRestore, onClose }) {
  const [copied, setCopied] = useState(false);
  const text = checklist.generateCopyText();

  const copy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="card" style={{ marginBottom: 16, borderColor: 'rgba(143,181,160,0.3)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <h3 style={{ fontSize: 14 }}>✅ Must-Do Items ({checklist.count})</h3>
        <div style={{ display: 'flex', gap: 6 }}>
          {checklist.count > 0 && (
            <button className="btn-secondary" onClick={copy} style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 4 }}>
              {copied ? <Check size={11} /> : <Copy size={11} />} {copied ? 'Copied!' : 'Copy'}
            </button>
          )}
          <button className="btn-ghost" onClick={() => checklist.clearAll()} style={{ fontSize: 11, color: 'var(--error)' }}>Clear all</button>
          <button className="btn-ghost" onClick={onClose}><X size={14} /></button>
        </div>
      </div>

      {checklist.count === 0 ? (
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 10 }}>No must-do items yet. Check the ☐ boxes in any day plan.</p>
      ) : (
        <pre style={{ fontSize: 11, color: 'var(--text-secondary)', background: 'var(--bg-input)', padding: 10, borderRadius: 6, maxHeight: 150, overflowY: 'auto', whiteSpace: 'pre-wrap', marginBottom: 10 }}>
          {text}
        </pre>
      )}

      <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: 10 }}>
        <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 6 }}>📋 Restore from copied text (paste below):</div>
        <textarea rows={3} placeholder="Paste your copied must-do list here to restore checkboxes..." value={restoreText} onChange={e => setRestoreText(e.target.value)}
          style={{ fontSize: 11, marginBottom: 8 }} />
        <button className="btn-secondary" onClick={onRestore} disabled={!restoreText.trim()} style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 4 }}>
          <RotateCcw size={11} /> Restore
        </button>
      </div>
    </div>
  );
}

// ---- Trip header ----
function TripHeader({ overview }) {
  const s = overview.tripSummary || {};
  return (
    <div className="card fade-in" style={{ marginBottom: 16, borderColor: 'rgba(212,132,90,0.2)' }}>
      <h1 style={{ fontSize: 20, marginBottom: 6, color: 'var(--text-accent)' }}>{s.title}</h1>
      <p style={{ color: 'var(--text-secondary)', lineHeight: 1.7, marginBottom: 8, fontSize: 13 }}>{s.description}</p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 8 }}>
        {s.highlights?.map(h => <span key={h} className="tag tag-accent">{h}</span>)}
      </div>
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
        {s.weatherNote && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>🌤 {s.weatherNote}</div>}
        {s.bestTimeToVisit && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>📅 {s.bestTimeToVisit}</div>}
      </div>
    </div>
  );
}

// ---- Editable price field ----
function EditablePrice({ value, inrValue, priceKey, priceOverrides, setPrice, currency }) {
  const [editing, setEditing] = useState(false);
  const current = priceOverrides[priceKey] !== undefined ? priceOverrides[priceKey] : inrValue;
  const isOverridden = priceOverrides[priceKey] !== undefined;

  if (editing) {
    return (
      <input
        autoFocus
        type="number"
        defaultValue={current}
        onBlur={e => { setPrice(priceKey, e.target.value); setEditing(false); }}
        onKeyDown={e => { if (e.key === 'Enter') { setPrice(priceKey, e.target.value); setEditing(false); } if (e.key === 'Escape') setEditing(false); }}
        style={{ width: 100, fontSize: 14, padding: '2px 6px', fontFamily: 'var(--font-display)' }}
      />
    );
  }

  return (
    <span
      onClick={() => setEditing(true)}
      title="Click to edit price"
      style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 4 }}
    >
      <span style={{ fontFamily: 'var(--font-display)', fontSize: 16, color: isOverridden ? 'var(--accent-coral)' : 'var(--accent-gold)' }}>
        {formatInr(current)}
      </span>
      <Pencil size={10} color="var(--text-muted)" />
      {isOverridden && <span style={{ fontSize: 9, color: 'var(--accent-coral)' }}>edited</span>}
    </span>
  );
}

// ---- Flights summary with editable prices ----
function FlightsSummary({ flights, priceOverrides, setPrice }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <h3 style={{ fontSize: 14, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
        <Plane size={13} color="var(--accent-primary)" /> Flights
      </h3>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        {[{ f: flights.outbound, label: 'OUTBOUND', key: 'flight_outbound' },
          { f: flights.return, label: 'RETURN', key: 'flight_return' }].filter(x => x.f).map(({ f, label, key }) => (
          <div key={key} className="card" style={{ padding: 12 }}>
            <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 2 }}>{label}</div>
            <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 3 }}>{f.from} → {f.to}</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginBottom: 6 }}>
              {f.duration} · {f.stops === 0 ? 'Direct' : `${f.stops} stop(s)`}
            </div>
            <EditablePrice inrValue={f.inrEquivalent} priceKey={key} priceOverrides={priceOverrides} setPrice={setPrice} currency={f.currency} />
            <div style={{ fontSize: 10, color: 'var(--text-muted)', marginBottom: 6 }}>{f.recommendedAirlines?.join(', ')}</div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {Object.entries(f.bookingLinks || {}).map(([name, url]) => url && (
                <a key={name} href={url} target="_blank" rel="noreferrer" style={{ fontSize: 10, color: 'var(--accent-blue)', display: 'flex', alignItems: 'center', gap: 2 }}>
                  {name === 'googleFlights' ? 'Google' : name === 'makemytrip' ? 'MMT' : name} <ExternalLink size={8} />
                </a>
              ))}
            </div>
            {f.tip && <div style={{ marginTop: 5, fontSize: 10, color: 'var(--text-muted)', fontStyle: 'italic' }}>💡 {f.tip}</div>}
          </div>
        ))}
      </div>
      {flights.intercity?.length > 0 && (
        <div style={{ marginTop: 8, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {flights.intercity.map((t, i) => (
            <div key={i} style={{ padding: '8px 12px', background: 'var(--bg-card)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-md)', fontSize: 12 }}>
              <span style={{ color: 'var(--text-secondary)' }}>{t.from} → {t.to}</span>
              <span className="tag tag-blue" style={{ marginLeft: 6, fontSize: 10 }}>{t.mode}</span>
              <EditablePrice inrValue={t.inrEquivalent} priceKey={`intercity_${i}`} priceOverrides={priceOverrides} setPrice={setPrice} />
              {t.bookingLink && <a href={t.bookingLink} target="_blank" rel="noreferrer" style={{ marginLeft: 8, fontSize: 10, color: 'var(--accent-blue)' }}>Book <ExternalLink size={8} /></a>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ---- Hotels summary with editable prices ----
function HotelsSummary({ hotels, priceOverrides, setPrice, cityPlan }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <h3 style={{ fontSize: 14, marginBottom: 8 }}>🏨 Hotels</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {hotels.map((h, i) => (
          <div key={i} className="card" style={{ padding: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                <span style={{ fontWeight: 600, fontSize: 13 }}>{h.hotelName}</span>
                <div style={{ display: 'flex', gap: 1 }}>
                  {Array.from({ length: h.stars || 4 }).map((_, si) => <Star key={si} size={8} fill="var(--accent-gold)" color="var(--accent-gold)" />)}
                </div>
              </div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>{h.city} · {h.area}</div>
              <div style={{ display: 'flex', gap: 8 }}>
                {h.bookingLinks?.booking && <a href={h.bookingLinks.booking} target="_blank" rel="noreferrer" style={{ fontSize: 10, color: 'var(--accent-blue)', display: 'flex', alignItems: 'center', gap: 2 }}>Booking <ExternalLink size={8} /></a>}
                <PlaceLinks name={h.hotelName} city={h.city} mapsLink={h.mapsLink} size="xs" />
              </div>
            </div>
            <div style={{ textAlign: 'right', flexShrink: 0, marginLeft: 10 }}>
              <EditablePrice inrValue={h.inrPerNight} priceKey={`hotel_${h.city}_night`} priceOverrides={priceOverrides} setPrice={setPrice} />
              <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>/night</div>
              <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 2 }}>
                Total: {formatInr((priceOverrides[`hotel_${h.city}_night`] ?? h.inrPerNight) * (cityPlan?.find(c => c.city === h.city)?.nights || 1))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---- City section ----
function CitySection({ city, expandedDays, loadingDays, activeDayPanel, onExpandDay }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8, padding: '10px 12px', background: 'var(--bg-card)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-subtle)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(212,132,90,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14 }}>🏙️</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 14 }}>{city.city}, {city.country}</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{city.nights} nights · {city.arrivalDate} → {city.departureDate}</div>
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 14, color: 'var(--accent-gold)', fontFamily: 'var(--font-display)' }}>{formatInr(city.estimatedDailyBudgetInr)}<span style={{ fontSize: 10, fontFamily: 'var(--font-ui)', color: 'var(--text-muted)' }}>/day</span></div>
          <span className={`tag ${city.costLevel === 'budget' ? 'tag-green' : city.costLevel === 'expensive' ? 'tag-accent' : 'tag-gold'}`} style={{ fontSize: 10 }}>{city.costLevel}</span>
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 5, paddingLeft: 8 }}>
        {city.days?.map(day => {
          const isExpanded = !!expandedDays[day.dayNumber];
          const isLoading = loadingDays[day.dayNumber];
          const isActive = activeDayPanel?.dayNumber === day.dayNumber;
          return (
            <button key={day.dayNumber} onClick={() => onExpandDay(day.dayNumber, city.city, day.date)}
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 12px', borderRadius: 'var(--radius-md)', background: isActive ? 'rgba(212,132,90,0.12)' : 'var(--bg-input)', border: isActive ? '1px solid rgba(212,132,90,0.4)' : '1px solid var(--border-subtle)', cursor: 'pointer', transition: 'all 0.2s', textAlign: 'left', width: '100%' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 26, height: 26, borderRadius: '50%', flexShrink: 0, background: isExpanded ? 'rgba(143,181,160,0.2)' : 'rgba(255,255,255,0.06)', color: isExpanded ? 'var(--accent-secondary)' : 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, border: isExpanded ? '1px solid rgba(143,181,160,0.3)' : 'none' }}>
                  {isLoading ? <span className="spinner" style={{ width: 11, height: 11 }} /> : day.dayNumber}
                </div>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 500, color: isActive ? 'var(--accent-primary)' : 'var(--text-primary)' }}>{day.theme}</div>
                  <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{day.date}</div>
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                {isExpanded && <span className="tag tag-green" style={{ fontSize: 10 }}>✓ Expanded</span>}
                {!isExpanded && !isLoading && <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>Tap to plan</span>}
                <ChevronRight size={13} color={isActive ? 'var(--accent-primary)' : 'var(--text-muted)'} />
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ---- Hidden gems with checkboxes ----
function HiddenGems({ cityPlan, checklist }) {
  const allGems = cityPlan.flatMap(c => (c.hiddenGems || []).map(g => ({ ...g, cityName: c.city, dayNumber: c.days?.[0]?.dayNumber })));
  if (!allGems.length) return null;
  return (
    <div style={{ marginTop: 20 }}>
      <h3 style={{ fontSize: 14, marginBottom: 8 }}>🔭 Hidden Gems</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 8 }}>
        {allGems.map((gem, i) => {
          const checked = checklist.isChecked(gem.dayNumber, 'Hidden Gem', gem.name);
          return (
            <div key={i} className="card" style={{ padding: 10, borderColor: checked ? 'rgba(143,181,160,0.4)' : 'var(--border-subtle)' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 6, marginBottom: 4 }}>
                <button onClick={() => checklist.toggle(gem.dayNumber, gem.cityName, 'Hidden Gem', gem.name)} style={{ background: 'none', flexShrink: 0, color: checked ? 'var(--accent-secondary)' : 'var(--text-muted)', marginTop: 1 }}>
                  {checked ? <CheckSquare size={14} /> : <Square size={14} />}
                </button>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 12 }}>{gem.name}</div>
                  <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{gem.cityName} · {gem.type}</div>
                </div>
              </div>
              <p style={{ fontSize: 11, color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: 6, marginLeft: 20 }}>{gem.description}</p>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginLeft: 20 }}>
                <span style={{ fontSize: 11, color: 'var(--accent-gold)' }}>{gem.cost === 0 ? 'Free' : formatInr(gem.inrCost)}</span>
                <PlaceLinks name={gem.name} city={gem.cityName} mapsLink={gem.mapsLink} size="xs" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ---- Useful links ----
function UsefulLinks({ links }) {
  const items = [
    { label: '🛂 Visa', url: links.visaInfo },
    { label: '🌤 Weather', url: links.weather },
    { label: '💱 Currency', url: links.currencyConverter },
    { label: '🛡 Insurance', url: links.travelInsurance },
  ].filter(i => i.url);
  if (!items.length) return null;
  return (
    <div style={{ marginTop: 16, marginBottom: 28 }}>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {items.map(item => (
          <a key={item.label} href={item.url} target="_blank" rel="noreferrer" className="btn-secondary" style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 4, textDecoration: 'none', padding: '6px 10px' }}>
            {item.label} <ExternalLink size={9} />
          </a>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// DAY DETAIL PANEL
// ============================================================
function DayPanel({ dayData, dayInfo, isLoading, onClose, onRegenerate, checklist, priceOverrides, setPrice, overview }) {
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [waStatus, setWaStatus] = useState('');

  const handleRegenerate = () => {
    onRegenerate(showFeedback && feedback.trim() ? feedback.trim() : null);
    setFeedback('');
    setShowFeedback(false);
  };

  const handleSendDay = async () => {
    try {
      const text = formatDayForWhatsApp(dayData, overview);
      const result = await sendToWhatsApp(text);
      setWaStatus(result.method === 'api' ? '✅ Sent!' : '📱 Opened WhatsApp');
      setTimeout(() => setWaStatus(''), 3000);
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div style={{ width: 420, flexShrink: 0, overflowY: 'auto', background: 'var(--bg-secondary)', display: 'flex', flexDirection: 'column' }}>
      {/* Panel header */}
      <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0, position: 'sticky', top: 0, background: 'var(--bg-secondary)', zIndex: 10 }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 14 }}>Day {dayInfo.dayNumber} — {dayInfo.cityName}</div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{dayInfo.date}</div>
        </div>
        <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
          {waStatus && <span style={{ fontSize: 11, color: 'var(--success)' }}>{waStatus}</span>}
          {dayData && (
            <button className="btn-ghost" onClick={handleSendDay} title="Send to WhatsApp" style={{ color: 'var(--accent-secondary)', display: 'flex', alignItems: 'center', gap: 4, fontSize: 11 }}>
              <Send size={13} />
            </button>
          )}
          <button className="btn-ghost" onClick={() => setShowFeedback(!showFeedback)} style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 11, color: 'var(--text-muted)' }}>
            <RefreshCw size={12} /> Redo
          </button>
          <button className="btn-ghost" onClick={onClose}><X size={15} /></button>
        </div>
      </div>

      {/* Checklist count for this day */}
      {dayData && checklist.getCheckedForDay(dayInfo.dayNumber).length > 0 && (
        <div style={{ padding: '6px 18px', background: 'rgba(143,181,160,0.08)', borderBottom: '1px solid rgba(143,181,160,0.15)', fontSize: 11, color: 'var(--accent-secondary)', display: 'flex', alignItems: 'center', gap: 6 }}>
          <CheckSquare size={12} /> {checklist.getCheckedForDay(dayInfo.dayNumber).length} must-do item(s) — protected on redo
        </div>
      )}

      {/* Feedback for regen */}
      {showFeedback && (
        <div style={{ padding: '10px 18px', borderBottom: '1px solid var(--border-subtle)', background: 'rgba(212,132,90,0.06)' }}>
          <input placeholder="Optional: what to change? (e.g. 'more food spots', 'avoid museums')" value={feedback} onChange={e => setFeedback(e.target.value)} style={{ marginBottom: 8, fontSize: 12 }} />
          <div style={{ display: 'flex', gap: 6 }}>
            <button className="btn-primary" onClick={handleRegenerate} disabled={isLoading} style={{ width: 'auto', padding: '7px 14px', fontSize: 12 }}>
              {isLoading ? 'Regenerating...' : 'Regenerate'}
            </button>
            <button className="btn-secondary" onClick={() => setShowFeedback(false)} style={{ fontSize: 12 }}>Cancel</button>
          </div>
        </div>
      )}

      {/* Loading */}
      {isLoading && (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, padding: 40 }}>
          <div className="spinner" style={{ width: 32, height: 32, borderWidth: 3 }} />
          <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Planning Day {dayInfo.dayNumber}...</p>
        </div>
      )}

      {/* No data */}
      {!isLoading && !dayData && (
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, padding: 40, textAlign: 'center' }}>
          <div style={{ fontSize: 32 }}>📋</div>
          <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Click a day on the left to load its plan here.</p>
        </div>
      )}

      {/* Day detail */}
      {!isLoading && dayData && (
        <div style={{ padding: '16px 18px', flex: 1 }}>
          <div style={{ marginBottom: 14 }}>
            <h3 style={{ fontSize: 15, color: 'var(--text-accent)', marginBottom: 4 }}>{dayData.theme}</h3>
            <EditablePrice
              inrValue={dayData.totalDayCostInr}
              priceKey={`day_${dayData.day}_total`}
              priceOverrides={priceOverrides}
              setPrice={setPrice}
            />
            <span style={{ fontSize: 11, color: 'var(--text-muted)', marginLeft: 6 }}>estimated total</span>
          </div>

          {[
            { label: 'Morning', emoji: '🌅', slot: 'morning', data: dayData.morning },
            { label: 'Afternoon', emoji: '☀️', slot: 'afternoon', data: dayData.afternoon },
            { label: 'Evening', emoji: '🌙', slot: 'evening', data: dayData.evening },
          ].map(({ label, emoji, slot, data }) => data && (
            <ActivityBlock
              key={slot}
              label={label} emoji={emoji} slot={slot} data={data}
              dayNumber={dayData.day} cityName={dayData.city}
              checklist={checklist}
              priceKey={`day_${dayData.day}_${slot}`}
              priceOverrides={priceOverrides} setPrice={setPrice}
            />
          ))}

          {dayData.food && <FoodBlock food={dayData.food} dayNumber={dayData.day} cityName={dayData.city} checklist={checklist} priceOverrides={priceOverrides} setPrice={setPrice} />}

          {dayData.localTransport && (
            <div style={{ marginTop: 10, padding: '8px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: 'var(--radius-sm)', display: 'flex', alignItems: 'center', gap: 8 }}>
              <Train size={12} color="var(--accent-secondary)" />
              <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{dayData.localTransport.mode} · </span>
              <EditablePrice inrValue={dayData.localTransport.inrCost} priceKey={`day_${dayData.day}_transport`} priceOverrides={priceOverrides} setPrice={setPrice} />
              {dayData.localTransport.tip && <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>· {dayData.localTransport.tip}</span>}
            </div>
          )}

          {dayData.notes && (
            <div style={{ marginTop: 10, padding: '10px 12px', background: 'rgba(201,169,110,0.08)', border: '1px solid rgba(201,169,110,0.15)', borderRadius: 'var(--radius-sm)' }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--accent-gold)', marginBottom: 4 }}>📝 NOTES</div>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{dayData.notes}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ---- Activity block with checkbox + editable price ----
function ActivityBlock({ label, emoji, slot, data, dayNumber, cityName, checklist, priceKey, priceOverrides, setPrice }) {
  const checked = checklist.isChecked(dayNumber, label, data.activity);
  return (
    <div style={{ marginBottom: 12, paddingBottom: 12, borderBottom: '1px solid var(--border-subtle)', background: checked ? 'rgba(143,181,160,0.05)' : 'transparent', borderRadius: checked ? 6 : 0 }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', padding: checked ? '6px 8px' : 0 }}>
        {/* Checkbox */}
        <button onClick={() => checklist.toggle(dayNumber, cityName, label, data.activity)}
          style={{ background: 'none', flexShrink: 0, color: checked ? 'var(--accent-secondary)' : 'var(--text-muted)', marginTop: 14 }}>
          {checked ? <CheckSquare size={14} /> : <Square size={14} />}
        </button>
        <span style={{ fontSize: 14, flexShrink: 0, marginTop: 12 }}>{emoji}</span>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, alignItems: 'center', marginBottom: 2 }}>
            <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 600 }}>{label.toUpperCase()}</span>
            <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>· {data.time}</span>
            {data.isOffbeat && <span className="tag tag-green" style={{ fontSize: 9 }}>🔭 Offbeat</span>}
            {checked && <span className="tag tag-green" style={{ fontSize: 9 }}>✅ Must-do</span>}
          </div>
          <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2 }}>{data.activity}</div>
          <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: 3 }}>{data.description}</p>
          {data.tip && <p style={{ fontSize: 11, color: 'var(--text-muted)', fontStyle: 'italic', marginBottom: 3 }}>💡 {data.tip}</p>}
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <EditablePrice inrValue={data.inrCost} priceKey={priceKey} priceOverrides={priceOverrides} setPrice={setPrice} />
            <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{data.duration}</span>
            <PlaceLinks name={data.activity} city={cityName} mapsLink={data.mapsLink} size="xs" />
            {data.bookingLink && (
              <a href={data.bookingLink} target="_blank" rel="noreferrer"
                style={{ fontSize: 10, color: 'var(--accent-secondary)', display: 'flex', alignItems: 'center', gap: 2 }}>
                Book <ExternalLink size={9} />
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ---- Food block with checkboxes + editable prices ----
function FoodBlock({ food, dayNumber, cityName, checklist, priceOverrides, setPrice }) {
  return (
    <div style={{ padding: '10px 12px', background: 'rgba(201,169,110,0.06)', borderRadius: 'var(--radius-sm)', border: '1px solid rgba(201,169,110,0.12)', marginBottom: 12 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 8 }}>
        <Utensils size={11} color="var(--accent-gold)" />
        <span style={{ fontSize: 10, fontWeight: 600, color: 'var(--accent-gold)' }}>FOOD</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8 }}>
        {[['🌅', 'Breakfast', food.breakfast, 'breakfast'],
          ['☀️', 'Lunch', food.lunch, 'lunch'],
          ['🌙', 'Dinner', food.dinner, 'dinner']].map(([emoji, mealLabel, meal, key]) => meal && (
          <div key={key}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 2 }}>
              <button onClick={() => checklist.toggle(dayNumber, cityName, mealLabel, meal.place)}
                style={{ background: 'none', color: checklist.isChecked(dayNumber, mealLabel, meal.place) ? 'var(--accent-secondary)' : 'var(--text-muted)' }}>
                {checklist.isChecked(dayNumber, mealLabel, meal.place) ? <CheckSquare size={11} /> : <Square size={11} />}
              </button>
              <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{emoji} {mealLabel}</span>
            </div>
            <div style={{ fontSize: 12, fontWeight: 500 }}>{meal.place}</div>
            <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{meal.type}</div>
            <EditablePrice inrValue={meal.inrCost} priceKey={`day_${dayNumber}_${key}`} priceOverrides={priceOverrides} setPrice={setPrice} />
            <PlaceLinks name={meal.place} city={cityName} mapsLink={meal.mapsLink} size="xs" />
          </div>
        ))}
      </div>
    </div>
  );
}
