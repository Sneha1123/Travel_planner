// ============================================================
// pricing/BudgetView.jsx — Budget KPI cards + breakdown
// ============================================================

import React, { useState } from 'react';
import { TrendingUp, TrendingDown, Target, DollarSign } from 'lucide-react';
import { formatInr, shortInr, getBudgetColor } from '../../utils/format.js';
import { optimizeBudget } from '../../utils/api.js';

export default function BudgetView({ overview, expandedDays, tripData }) {
  const [targetBudget, setTargetBudget] = useState('');
  const [optimization, setOptimization] = useState(null);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optError, setOptError] = useState(null);

  const bd = overview?.budgetSummary || {};

  const handleOptimize = async () => {
    if (!targetBudget) return alert('Enter your target budget first');
    setIsOptimizing(true);
    setOptError(null);
    try {
      const result = await optimizeBudget(tripData, bd.grandTotalInr, parseFloat(targetBudget), 'INR');
      setOptimization(result.optimization);
    } catch (err) {
      setOptError(err?.response?.data?.error || err.message);
    } finally {
      setIsOptimizing(false);
    }
  };

  if (!bd.grandTotal) {
    return <div style={{ padding: 40, color: 'var(--text-muted)', textAlign: 'center' }}>No budget data yet. Generate an itinerary first.</div>;
  }

  const kpis = [
    { label: 'Grand Total', value: shortInr(bd.grandTotalInr), sub: `${bd.currency} ${bd.grandTotal?.toLocaleString()}`, color: 'var(--accent-gold)' },
    { label: 'Per Day', value: shortInr(bd.perDayInr), sub: `${tripData.numDays || '?'} days`, color: 'var(--accent-secondary)' },
    { label: 'Your Budget', value: shortInr(bd.targetBudget), sub: tripData.currency, color: 'var(--text-secondary)' },
    { label: bd.isOverBudget ? 'Over Budget' : 'Under Budget', value: shortInr(Math.abs(bd.budgetDifferenceInr || 0)), sub: bd.isOverBudget ? '⚠️ Needs reduction' : '✅ Within budget', color: getBudgetColor(bd.isOverBudget ? -1 : 1) },
    { label: 'Exchange Rate', value: `₹${bd.exchangeRateToInr}`, sub: `per 1 ${bd.currency}`, color: 'var(--text-muted)' },
  ];

  const breakdownItems = [
    { label: '✈️ Flights', inr: bd.flights?.totalInr, pct: pct(bd.flights?.totalInr, bd.grandTotalInr), color: 'var(--accent-primary)' },
    { label: '🏨 Accommodation', inr: bd.accommodation?.totalInr, pct: pct(bd.accommodation?.totalInr, bd.grandTotalInr), color: 'var(--accent-secondary)' },
    { label: '🚆 Intercity Travel', inr: bd.intercityTransport?.totalInr, pct: pct(bd.intercityTransport?.totalInr, bd.grandTotalInr), color: 'var(--accent-blue)' },
    { label: '🍽️ Food & Activities', inr: bd.foodAndActivities?.totalInr, pct: pct(bd.foodAndActivities?.totalInr, bd.grandTotalInr), color: 'var(--accent-gold)' },
    { label: '🛡 Buffer', inr: bd.buffer?.totalInr, pct: pct(bd.buffer?.totalInr, bd.grandTotalInr), color: 'var(--text-muted)' },
  ].filter(item => item.inr > 0);

  return (
    <div style={{ padding: '24px 28px', maxWidth: 900, margin: '0 auto' }}>

      {/* KPI Cards */}
      <h2 style={{ fontSize: 20, marginBottom: 16 }}>💰 Budget Overview</h2>
      <div className="kpi-grid" style={{ marginBottom: 28 }}>
        {kpis.map(kpi => (
          <div key={kpi.label} className="kpi-card">
            <div className="kpi-label">{kpi.label}</div>
            <div className="kpi-value" style={{ color: kpi.color }}>{kpi.value}</div>
            <div className="kpi-sub">{kpi.sub}</div>
          </div>
        ))}
      </div>

      {/* Visual Breakdown */}
      <div className="card" style={{ marginBottom: 24 }}>
        <h3 style={{ fontSize: 15, marginBottom: 16 }}>Breakdown by Category</h3>
        {breakdownItems.map(item => (
          <div key={item.label} style={{ marginBottom: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
              <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{item.label}</span>
              <div style={{ textAlign: 'right' }}>
                <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{formatInr(item.inr)}</span>
                <span style={{ fontSize: 11, color: 'var(--text-muted)', marginLeft: 8 }}>{item.pct}%</span>
              </div>
            </div>
            <div style={{ height: 6, background: 'var(--bg-input)', borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ height: '100%', width: `${item.pct}%`, background: item.color, borderRadius: 3, transition: 'width 0.5s ease' }} />
            </div>
          </div>
        ))}
      </div>

      {/* City-wise cost table */}
      {overview.cityPlan?.length > 0 && (
        <div className="card" style={{ marginBottom: 24 }}>
          <h3 style={{ fontSize: 15, marginBottom: 14 }}>City-by-City Budget</h3>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                {['City', 'Nights', 'Daily Budget', 'Est. Total'].map(h => (
                  <th key={h} style={{ padding: '6px 10px', textAlign: h === 'Est. Total' || h === 'Daily Budget' ? 'right' : 'left', color: 'var(--text-muted)', fontWeight: 600, fontSize: 11 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {overview.cityPlan.map(city => (
                <tr key={city.city} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                  <td style={{ padding: '8px 10px', color: 'var(--accent-primary)', fontWeight: 600 }}>{city.city}</td>
                  <td style={{ padding: '8px 10px', color: 'var(--text-secondary)' }}>{city.nights}</td>
                  <td style={{ padding: '8px 10px', textAlign: 'right', color: 'var(--text-secondary)' }}>{formatInr(city.estimatedDailyBudgetInr)}</td>
                  <td style={{ padding: '8px 10px', textAlign: 'right', fontFamily: 'var(--font-display)', color: 'var(--accent-gold)' }}>
                    {formatInr((city.estimatedDailyBudgetInr || 0) * (city.nights || 1))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Budget Optimizer */}
      <div className="card" style={{ marginBottom: 28, borderColor: 'rgba(201,169,110,0.2)' }}>
        <h3 style={{ fontSize: 15, marginBottom: 8 }}>🎯 Budget Optimizer</h3>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 14 }}>
          Enter your target budget and Claude will suggest what to change to hit it.
        </p>
        <div style={{ display: 'flex', gap: 10 }}>
          <input
            type="number"
            placeholder={`Target budget in INR (current: ${formatInr(bd.grandTotalInr)})`}
            value={targetBudget}
            onChange={e => setTargetBudget(e.target.value)}
            style={{ flex: 1 }}
          />
          <button
            className="btn-primary"
            onClick={handleOptimize}
            disabled={isOptimizing}
            style={{ width: 'auto', padding: '10px 20px', display: 'flex', alignItems: 'center', gap: 6 }}
          >
            {isOptimizing ? <span className="spinner" style={{ width: 14, height: 14 }} /> : <Target size={14} />}
            Optimize
          </button>
        </div>

        {optError && <p style={{ color: 'var(--error)', fontSize: 12, marginTop: 8 }}>{optError}</p>}

        {optimization && !optimization.parsed === false && (
          <div style={{ marginTop: 16 }}>
            <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 12 }}>{optimization.summary}</p>
            {optimization.optimizations?.map((opt, i) => (
              <div key={i} style={{ marginBottom: 8, padding: '10px 14px', background: 'rgba(255,255,255,0.03)', borderRadius: 'var(--radius-sm)', display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <span className={`tag tag-${opt.impact === 'high' ? 'accent' : opt.impact === 'medium' ? 'gold' : 'muted'}`} style={{ flexShrink: 0 }}>
                  Save {formatInr(opt.potentialSavingInr || opt.saving * 83.5)}
                </span>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2 }}>{opt.action}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{opt.details}</div>
                </div>
              </div>
            ))}
            {optimization.tips?.length > 0 && (
              <div style={{ marginTop: 12 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', marginBottom: 6 }}>ADDITIONAL TIPS</div>
                {optimization.tips.map((tip, i) => (
                  <div key={i} style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 4 }}>• {tip}</div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Helper: percentage
function pct(value, total) {
  if (!value || !total) return 0;
  return Math.round((value / total) * 100);
}
