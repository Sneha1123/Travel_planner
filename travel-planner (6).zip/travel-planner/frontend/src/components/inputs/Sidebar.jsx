// ============================================================
// inputs/Sidebar.jsx — All trip input fields + Generate button
// ============================================================

import React, { useState } from 'react';
import { ChevronLeft, Sparkles, Loader } from 'lucide-react';
import { generateOverview } from '../../utils/api.js';

// All travel style options
const TRAVEL_STYLES = [
  { id: 'offbeat', label: '🔭 Offbeat' },
  { id: 'popular', label: '⭐ Popular' },
  { id: 'luxury', label: '💎 Luxury' },
  { id: 'budget', label: '💰 Budget' },
  { id: 'honeymoon', label: '💑 Honeymoon' },
  { id: 'culture', label: '🎭 Culture' },
  { id: 'food', label: '🍜 Food' },
  { id: 'nightlife', label: '🌃 Nightlife' },
  { id: 'nature', label: '🌿 Nature' },
  { id: 'relaxed', label: '🧘 Relaxed' },
];

const COMMUTE_OPTIONS = [
  { id: 'train', label: '🚆 Train' },
  { id: 'flight', label: '✈️ Flight' },
  { id: 'bus', label: '🚌 Bus' },
  { id: 'car_rental', label: '🚗 Car Rental' },
  { id: 'private_transfer', label: '🚐 Private Transfer' },
  { id: 'public_transport', label: '🚇 Public/Metro' },
];

export default function Sidebar({ tripData, setTripData, isGenerating, setIsGenerating, setOverview, setGenerateError, onCollapse, manualEntries }) {
  const [section, setSection] = useState('basics'); // basics | style | flights | hotels | commute

  const update = (key, value) => setTripData(prev => ({ ...prev, [key]: value }));

  const toggleArrayItem = (key, value) => {
    setTripData(prev => {
      const arr = prev[key] || [];
      return { ...prev, [key]: arr.includes(value) ? arr.filter(x => x !== value) : [...arr, value] };
    });
  };

  const handleGenerate = async () => {
    // Basic validation
    if (!tripData.fromCity) return alert('Please enter your departure city');
    if (!tripData.toCountries.length) return alert('Please add at least one destination');
    if (!tripData.startDate || !tripData.endDate) return alert('Please set travel dates');

    setIsGenerating(true);
    setGenerateError(null);
    setOverview(null);

    try {
      const result = await generateOverview(tripData, manualEntries || []);
      if (result.parsed && result.overview) {
        setOverview(result.overview);
      } else {
        setGenerateError('Could not parse the trip overview. Please try again.');
      }
    } catch (err) {
      const msg = err?.response?.data?.error || err.message || 'Failed to generate trip overview';
      setGenerateError(msg);
    } finally {
      setIsGenerating(false);
    }
  };

  const sections = [
    { id: 'basics', label: 'Trip Basics' },
    { id: 'style', label: 'Travel Style' },
    { id: 'flights', label: 'Flights' },
    { id: 'hotels', label: 'Hotels' },
    { id: 'commute', label: 'Commute' },
  ];

  return (
    <div className="sidebar">
      {/* Header */}
      <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 15, color: 'var(--text-accent)' }}>Plan Your Trip</span>
        <button className="btn-ghost" onClick={onCollapse} title="Collapse sidebar">
          <ChevronLeft size={16} />
        </button>
      </div>

      {/* Section tabs */}
      <div style={{ display: 'flex', gap: 0, padding: '10px 12px', borderBottom: '1px solid var(--border-subtle)', flexShrink: 0, flexWrap: 'wrap', gap: 4 }}>
        {sections.map(s => (
          <button
            key={s.id}
            onClick={() => setSection(s.id)}
            style={{
              padding: '5px 10px', borderRadius: 6, fontSize: 11, fontWeight: 500,
              background: section === s.id ? 'rgba(212,132,90,0.15)' : 'transparent',
              color: section === s.id ? 'var(--accent-primary)' : 'var(--text-muted)',
              border: section === s.id ? '1px solid rgba(212,132,90,0.3)' : '1px solid transparent',
              cursor: 'pointer', transition: 'all 0.2s'
            }}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Scrollable content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }}>

        {/* ---- BASICS ---- */}
        {section === 'basics' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <Field label="Travelling From City">
              <input
                placeholder="e.g. Chennai, Mumbai, Delhi"
                value={tripData.fromCity}
                onChange={e => update('fromCity', e.target.value)}
              />
            </Field>

            <Field label="Destinations (countries/cities)">
              <TagInput
                placeholder="Type a place and press Enter"
                tags={tripData.toCountries}
                onAdd={val => update('toCountries', [...(tripData.toCountries || []), val])}
                onRemove={val => update('toCountries', tripData.toCountries.filter(x => x !== val))}
              />
            </Field>

            <Field label="Must-Visit Places (optional)">
              <TagInput
                placeholder="e.g. Prague, Vienna, Santorini"
                tags={tripData.mustVisitPlaces}
                onAdd={val => update('mustVisitPlaces', [...(tripData.mustVisitPlaces || []), val])}
                onRemove={val => update('mustVisitPlaces', tripData.mustVisitPlaces.filter(x => x !== val))}
              />
            </Field>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <Field label="Start Date">
                <input
                  type="date"
                  value={tripData.startDate}
                  onChange={e => {
                    const start = e.target.value;
                    const updates = { startDate: start };
                    // If numDays is set, auto-calculate end date
                    if (tripData.numDays && start) {
                      const endDate = new Date(start);
                      endDate.setDate(endDate.getDate() + parseInt(tripData.numDays) - 1);
                      updates.endDate = endDate.toISOString().split('T')[0];
                    }
                    // If end date is set, auto-calculate numDays
                    else if (tripData.endDate && start) {
                      const diff = Math.round((new Date(tripData.endDate) - new Date(start)) / (1000 * 60 * 60 * 24)) + 1;
                      if (diff > 0) updates.numDays = diff;
                    }
                    setTripData(prev => ({ ...prev, ...updates }));
                  }}
                />
              </Field>
              <Field label="End Date">
                <input
                  type="date"
                  value={tripData.endDate}
                  onChange={e => {
                    const end = e.target.value;
                    const updates = { endDate: end };
                    // If start date is set, auto-calculate numDays
                    if (tripData.startDate && end) {
                      const diff = Math.round((new Date(end) - new Date(tripData.startDate)) / (1000 * 60 * 60 * 24)) + 1;
                      if (diff > 0) updates.numDays = diff;
                    }
                    setTripData(prev => ({ ...prev, ...updates }));
                  }}
                />
              </Field>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <Field label="No. of Days">
                <input
                  type="number" min="1" max="60"
                  placeholder="e.g. 10"
                  value={tripData.numDays}
                  onChange={e => {
                    const days = e.target.value;
                    const updates = { numDays: days };
                    // If start date is set, auto-calculate end date
                    if (tripData.startDate && days) {
                      const endDate = new Date(tripData.startDate);
                      endDate.setDate(endDate.getDate() + parseInt(days) - 1);
                      updates.endDate = endDate.toISOString().split('T')[0];
                    }
                    setTripData(prev => ({ ...prev, ...updates }));
                  }}
                />
              </Field>
              <Field label="Travelers">
                <input
                  type="number" min="1" max="20"
                  value={tripData.travelers}
                  onChange={e => update('travelers', parseInt(e.target.value) || 1)}
                />
              </Field>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <Field label="Total Budget">
                <input
                  type="number"
                  placeholder="e.g. 200000"
                  value={tripData.totalBudget}
                  onChange={e => update('totalBudget', e.target.value)}
                />
              </Field>
              <Field label="Currency">
                <select value={tripData.currency} onChange={e => update('currency', e.target.value)}>
                  <option value="INR">INR ₹</option>
                  <option value="USD">USD $</option>
                  <option value="EUR">EUR €</option>
                  <option value="GBP">GBP £</option>
                  <option value="AED">AED</option>
                  <option value="SGD">SGD</option>
                </select>
              </Field>
            </div>
          </div>
        )}

        {/* ---- TRAVEL STYLE ---- */}
        {section === 'style' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <div className="section-label">Travel Vibe (select all that apply)</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {TRAVEL_STYLES.map(style => (
                  <button
                    key={style.id}
                    onClick={() => toggleArrayItem('travelStyle', style.id)}
                    style={{
                      padding: '7px 13px', borderRadius: 20, fontSize: 12,
                      background: tripData.travelStyle?.includes(style.id) ? 'rgba(212,132,90,0.2)' : 'var(--bg-card)',
                      color: tripData.travelStyle?.includes(style.id) ? 'var(--accent-primary)' : 'var(--text-secondary)',
                      border: tripData.travelStyle?.includes(style.id) ? '1px solid rgba(212,132,90,0.4)' : '1px solid var(--border-subtle)',
                      cursor: 'pointer', transition: 'all 0.2s'
                    }}
                  >
                    {style.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ---- FLIGHTS ---- */}
        {section === 'flights' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <Field label="Cabin Class">
              <select value={tripData.flightClass} onChange={e => update('flightClass', e.target.value)}>
                <option value="economy">Economy</option>
                <option value="premium_economy">Premium Economy</option>
                <option value="business">Business</option>
                <option value="first">First Class</option>
              </select>
            </Field>

            <Field label="Preferred Airlines (optional)">
              <input
                placeholder="e.g. Emirates, Air India, IndiGo"
                value={tripData.preferredAirlines}
                onChange={e => update('preferredAirlines', e.target.value)}
              />
            </Field>

            <Field label="Avoid Airlines (optional)">
              <input
                placeholder="e.g. XYZ Air"
                value={tripData.avoidAirlines}
                onChange={e => update('avoidAirlines', e.target.value)}
              />
            </Field>

            <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={tripData.directOnly}
                onChange={e => update('directOnly', e.target.checked)}
                style={{ width: 'auto', accentColor: 'var(--accent-primary)' }}
              />
              <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Direct flights only</span>
            </label>

            {!tripData.directOnly && (
              <Field label="Max Layover Duration">
                <select value={tripData.maxLayover} onChange={e => update('maxLayover', e.target.value)}>
                  <option value="">No preference</option>
                  <option value="2h">2 hours</option>
                  <option value="4h">4 hours</option>
                  <option value="6h">6 hours</option>
                  <option value="8h">8 hours</option>
                  <option value="12h">12 hours</option>
                </select>
              </Field>
            )}
          </div>
        )}

        {/* ---- HOTELS ---- */}
        {section === 'hotels' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <Field label="Hotel Vibe / Type">
              <input
                placeholder="e.g. boutique, romantic, clean, safe, not too commercial"
                value={tripData.hotelVibe}
                onChange={e => update('hotelVibe', e.target.value)}
              />
            </Field>

            <Field label="Preferred Area / Neighborhood">
              <input
                placeholder="e.g. near the old town, canal area, beach"
                value={tripData.hotelAreas}
                onChange={e => update('hotelAreas', e.target.value)}
              />
            </Field>

            <Field label="Star Rating">
              <select value={tripData.hotelStars} onChange={e => update('hotelStars', parseInt(e.target.value))}>
                <option value={2}>2 stars (Budget)</option>
                <option value={3}>3 stars (Mid-range)</option>
                <option value={4}>4 stars (Comfortable)</option>
                <option value={5}>5 stars (Luxury)</option>
              </select>
            </Field>

            <Field label="Room Type">
              <select value={tripData.roomType} onChange={e => update('roomType', e.target.value)}>
                <option value="single">Single</option>
                <option value="double">Double</option>
                <option value="twin">Twin</option>
                <option value="suite">Suite</option>
                <option value="villa">Villa / Apartment</option>
              </select>
            </Field>

            <Field label={`Budget per Night (${tripData.currency})`}>
              <input
                type="number"
                placeholder="e.g. 8000"
                value={tripData.hotelBudgetPerNight}
                onChange={e => update('hotelBudgetPerNight', e.target.value)}
              />
            </Field>
          </div>
        )}

        {/* ---- COMMUTE ---- */}
        {section === 'commute' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <div className="section-label">Preferred Transport Between Cities</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {COMMUTE_OPTIONS.map(opt => (
                  <button
                    key={opt.id}
                    onClick={() => toggleArrayItem('commutePrefs', opt.id)}
                    style={{
                      padding: '7px 13px', borderRadius: 20, fontSize: 12,
                      background: tripData.commutePrefs?.includes(opt.id) ? 'rgba(143,181,160,0.2)' : 'var(--bg-card)',
                      color: tripData.commutePrefs?.includes(opt.id) ? 'var(--accent-secondary)' : 'var(--text-secondary)',
                      border: tripData.commutePrefs?.includes(opt.id) ? '1px solid rgba(143,181,160,0.4)' : '1px solid var(--border-subtle)',
                      cursor: 'pointer', transition: 'all 0.2s'
                    }}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Generate button — always visible */}
      <div style={{ padding: '16px 20px', borderTop: '1px solid var(--border-subtle)', flexShrink: 0 }}>
        <button
          className="btn-primary"
          onClick={handleGenerate}
          disabled={isGenerating}
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}
        >
          {isGenerating ? (
            <><span className="spinner" style={{ width: 16, height: 16 }} /> Generating your trip...</>
          ) : (
            <><Sparkles size={16} /> Generate Itinerary</>
          )}
        </button>
        {isGenerating && (
          <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 8, textAlign: 'center' }}>
            Claude is planning your trip. This takes 15–30 seconds...
          </p>
        )}
      </div>
    </div>
  );
}

// ---- Helper: Field wrapper ----
function Field({ label, children }) {
  return (
    <div>
      <div className="section-label" style={{ marginBottom: 6 }}>{label}</div>
      {children}
    </div>
  );
}

// ---- Helper: Tag input (destinations, must-visit places) ----
function TagInput({ placeholder, tags = [], onAdd, onRemove }) {
  const [input, setInput] = useState('');

  const handleKeyDown = (e) => {
    if ((e.key === 'Enter' || e.key === ',') && input.trim()) {
      e.preventDefault();
      const val = input.trim().replace(/,$/, '');
      if (val && !tags.includes(val)) onAdd(val);
      setInput('');
    }
    if (e.key === 'Backspace' && !input && tags.length) {
      onRemove(tags[tags.length - 1]);
    }
  };

  return (
    <div style={{
      display: 'flex', flexWrap: 'wrap', gap: 6, alignItems: 'center',
      background: 'var(--bg-input)', border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-sm)', padding: '8px 10px', minHeight: 42
    }}>
      {tags.map(tag => (
        <span key={tag} style={{
          display: 'inline-flex', alignItems: 'center', gap: 4,
          background: 'rgba(212,132,90,0.15)', color: 'var(--accent-primary)',
          border: '1px solid rgba(212,132,90,0.25)', borderRadius: 12,
          padding: '2px 8px', fontSize: 11, fontWeight: 500
        }}>
          {tag}
          <button onClick={() => onRemove(tag)} style={{ background: 'none', fontSize: 12, color: 'var(--accent-primary)', lineHeight: 1, padding: 0 }}>×</button>
        </span>
      ))}
      <input
        value={input}
        onChange={e => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={tags.length ? '' : placeholder}
        style={{ border: 'none', background: 'transparent', outline: 'none', flex: 1, minWidth: 80, padding: 0, fontSize: 12 }}
      />
    </div>
  );
}
