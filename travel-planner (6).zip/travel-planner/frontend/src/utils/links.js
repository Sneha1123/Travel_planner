// ============================================================
// utils/links.js
// Generates reliable Google Maps + Search links for any place
// Used as fallback when Claude returns empty/generic links
// ============================================================

// Build a Google Maps search link
export const mapsLink = (placeName, city = '', country = '') => {
  const query = [placeName, city, country].filter(Boolean).join(' ');
  return `https://www.google.com/maps/search/${encodeURIComponent(query)}`;
};

// Build a Google Search link (photos, reviews, info)
export const searchLink = (placeName, city = '') => {
  const query = [placeName, city].filter(Boolean).join(' ');
  return `https://www.google.com/search?q=${encodeURIComponent(query)}`;
};

// Build a Google Images link
export const imagesLink = (placeName, city = '') => {
  const query = [placeName, city].filter(Boolean).join(' ');
  return `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=isch`;
};

// Build a TripAdvisor search link
export const tripAdvisorLink = (placeName, city = '') => {
  const query = [placeName, city].filter(Boolean).join(' ');
  return `https://www.tripadvisor.com/Search?q=${encodeURIComponent(query)}`;
};

// Ensure a maps link is real (not a placeholder like "https://www.google.com/maps/search/ActivityName+City")
export const ensureMapsLink = (existing, placeName, city = '') => {
  if (!existing) return mapsLink(placeName, city);
  // Detect placeholder links — contain literal "ActivityName", "PlaceName", "HotelName"
  const placeholders = ['ActivityName', 'PlaceName', 'HotelName', 'PLACE_NAME', 'place+name'];
  const isPlaceholder = placeholders.some(p => existing.includes(p));
  if (isPlaceholder) return mapsLink(placeName, city);
  return existing;
};

// Get all links for a place (Maps + Search + Images)
export const getPlaceLinks = (placeName, city = '', existingMapsLink = null) => ({
  maps: ensureMapsLink(existingMapsLink, placeName, city),
  search: searchLink(placeName, city),
  images: imagesLink(placeName, city),
});
