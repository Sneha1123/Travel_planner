// ============================================================
// utils/whatsapp.js — WhatsApp send helpers
// Tries Cloud API first, falls back to wa.me quick share
// ============================================================

import { sendWhatsApp } from './api.js';

// Get saved recipient number
export const getSavedWaNumber = () =>
  localStorage.getItem('wa_number') || '';

export const saveWaNumber = (num) =>
  localStorage.setItem('wa_number', num);

// Send via Cloud API or fallback to wa.me
export const sendToWhatsApp = async (text, number) => {
  const to = number || getSavedWaNumber();
  if (!to) {
    throw new Error('No WhatsApp number set. Enter one in the My Links tab.');
  }

  try {
    // Try Cloud API first
    await sendWhatsApp(to, text);
    return { method: 'api', success: true };
  } catch (apiErr) {
    // Fallback: open wa.me with pre-filled text
    const cleanNumber = to.replace(/[\s\-\(\)\+]/g, '');
    const encoded = encodeURIComponent(text.slice(0, 4000)); // WA URL limit
    window.open(`https://wa.me/${cleanNumber}?text=${encoded}`, '_blank');
    return { method: 'quick_share', success: true };
  }
};

// Format a single day for WhatsApp
export const formatDayForWhatsApp = (dayData, overview) => {
  if (!dayData) return '';
  const lines = [
    `📅 *Day ${dayData.day} — ${dayData.city}*`,
    `📌 ${dayData.theme}`,
    '',
    `🌅 *Morning (${dayData.morning?.time})*`,
    `${dayData.morning?.activity}`,
    `📍 ${dayData.morning?.description}`,
    dayData.morning?.mapsLink ? `🗺 ${dayData.morning.mapsLink}` : '',
    '',
    `☀️ *Afternoon (${dayData.afternoon?.time})*`,
    `${dayData.afternoon?.activity}`,
    `📍 ${dayData.afternoon?.description}`,
    dayData.afternoon?.mapsLink ? `🗺 ${dayData.afternoon.mapsLink}` : '',
    '',
    `🌙 *Evening (${dayData.evening?.time})*`,
    `${dayData.evening?.activity}`,
    `📍 ${dayData.evening?.description}`,
    dayData.evening?.mapsLink ? `🗺 ${dayData.evening.mapsLink}` : '',
    '',
    `🍽 *Food*`,
    dayData.food?.breakfast ? `Breakfast: ${dayData.food.breakfast.place} (${dayData.food.breakfast.type})` : '',
    dayData.food?.lunch ? `Lunch: ${dayData.food.lunch.place} (${dayData.food.lunch.type})` : '',
    dayData.food?.dinner ? `Dinner: ${dayData.food.dinner.place} (${dayData.food.dinner.type})` : '',
    '',
    `💰 *Estimated Day Cost: ₹${dayData.totalDayCostInr?.toLocaleString('en-IN') || '—'}*`,
    dayData.notes ? `\n📝 ${dayData.notes}` : '',
    '',
    '_Shared via Smart Travel Planner_'
  ];
  return lines.filter(l => l !== '').join('\n');
};

// Format full overview for WhatsApp
export const formatOverviewForWhatsApp = (overview, expandedDays) => {
  const s = overview?.tripSummary || {};
  const bd = overview?.budgetSummary || {};

  const lines = [
    `🌍 *${s.title}*`,
    s.description || '',
    '',
    `📅 *City Plan*`,
    ...(overview?.cityPlan || []).map(c =>
      `• ${c.city}, ${c.country} — ${c.nights} nights (${c.arrivalDate} to ${c.departureDate})`
    ),
    '',
    `✈️ *Flights*`,
  ];

  if (overview?.flights?.outbound) {
    const f = overview.flights.outbound;
    lines.push(`Outbound: ${f.from} → ${f.to} | ${f.duration} | ₹${f.inrEquivalent?.toLocaleString('en-IN')}`);
    if (f.bookingLinks?.googleFlights) lines.push(`Book: ${f.bookingLinks.googleFlights}`);
  }
  if (overview?.flights?.return) {
    const f = overview.flights.return;
    lines.push(`Return: ${f.from} → ${f.to} | ₹${f.inrEquivalent?.toLocaleString('en-IN')}`);
  }

  lines.push('', `🏨 *Hotels*`);
  (overview?.hotels || []).forEach(h => {
    lines.push(`• ${h.city}: ${h.hotelName} (${h.stars}★) — ₹${h.inrPerNight?.toLocaleString('en-IN')}/night`);
    if (h.bookingLinks?.booking) lines.push(`  Book: ${h.bookingLinks.booking}`);
  });

  lines.push('', `💰 *Budget Summary*`);
  lines.push(`Total: ₹${bd.grandTotalInr?.toLocaleString('en-IN') || '—'}`);
  lines.push(`Per Day: ₹${bd.perDayInr?.toLocaleString('en-IN') || '—'}`);
  if (bd.isOverBudget) lines.push(`⚠️ Over budget by ₹${Math.abs(bd.budgetDifferenceInr || 0).toLocaleString('en-IN')}`);
  else lines.push(`✅ Within budget`);

  // Add any expanded days
  const expandedCount = Object.keys(expandedDays || {}).length;
  if (expandedCount > 0) {
    lines.push('', `📋 *${expandedCount} Day(s) Planned*`);
    Object.values(expandedDays).sort((a, b) => a.day - b.day).forEach(day => {
      lines.push(`Day ${day.day} (${day.city}): ${day.theme}`);
    });
  }

  lines.push('', '_Shared via Smart Travel Planner_');
  return lines.filter(l => l !== null && l !== undefined).join('\n');
};
