// ============================================================
// utils/api.js — All API calls to the backend
// Single source of truth for every network request
// ============================================================

import axios from 'axios';

const BASE = '/api'; // Vite proxies this to http://localhost:3001

// ---- Health check ----
export const checkHealth = () =>
  axios.get(`${BASE}/health`).then(r => r.data);

// ---- AI Calls ----
export const generateOverview = (tripData, manualEntries = []) =>
  axios.post(`${BASE}/ai/generate-overview`, { tripData, manualEntries }).then(r => r.data);

export const expandDay = (tripData, overview, dayNumber, cityName, date) =>
  axios.post(`${BASE}/ai/expand-day`, { tripData, overview, dayNumber, cityName, date }).then(r => r.data);

export const regenerateDay = (tripData, overview, dayNumber, cityName, date, feedback) =>
  axios.post(`${BASE}/ai/regenerate-day`, { tripData, overview, dayNumber, cityName, date, feedback }).then(r => r.data);

export const sendChatMessage = (message, tripContext, chatHistory) =>
  axios.post(`${BASE}/ai/chat`, { message, tripContext, chatHistory }).then(r => r.data);

export const optimizeBudget = (tripData, currentCost, targetBudget, currency) =>
  axios.post(`${BASE}/ai/optimize-budget`, { tripData, currentCost, targetBudget, currency }).then(r => r.data);

// ---- Currency ----
export const getExchangeRates = () =>
  axios.get(`${BASE}/currency/rates`).then(r => r.data);

export const convertToInr = (amount, from) =>
  axios.get(`${BASE}/currency/convert`, { params: { amount, from } }).then(r => r.data);

// ---- Live Data ----
export const getLiveStatus = () =>
  axios.get(`${BASE}/live/status`).then(r => r.data);

export const searchFlights = (params) =>
  axios.post(`${BASE}/live/flights`, params).then(r => r.data);

export const searchHotels = (params) =>
  axios.post(`${BASE}/live/hotels`, params).then(r => r.data);

// ---- Export ----
export const exportTrip = (tripData, itinerary, manualEntries) =>
  axios.post(`${BASE}/export/trip`, { tripData, itinerary, manualEntries }).then(r => r.data);

export const saveManualEntry = (entry) =>
  axios.post(`${BASE}/export/manual-entry`, entry).then(r => r.data);

export const getManualEntries = () =>
  axios.get(`${BASE}/export/manual-entries`).then(r => r.data);

// ---- WhatsApp ----
export const sendWhatsApp = (to, message) =>
  axios.post(`${BASE}/whatsapp/send`, { to, message }).then(r => r.data);

export const getWhatsAppStatus = () =>
  axios.get(`${BASE}/whatsapp/status`).then(r => r.data);
export const getErrorMessage = (err) => {
  return err?.response?.data?.error || err?.message || 'Something went wrong';
};
