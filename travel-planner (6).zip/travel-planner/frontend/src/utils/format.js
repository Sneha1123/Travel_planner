// ============================================================
// utils/format.js — Number, currency, date formatting helpers
// ============================================================

// Format INR amount with ₹ sign and Indian comma system
export const formatInr = (amount) => {
  if (amount == null || isNaN(amount)) return '₹0';
  return `₹${Math.round(amount).toLocaleString('en-IN')}`;
};

// Format any currency
export const formatCurrency = (amount, currencyCode) => {
  if (amount == null || isNaN(amount)) return '—';
  const symbols = {
    USD: '$', EUR: '€', GBP: '£', AED: 'AED ', SGD: 'S$',
    THB: '฿', JPY: '¥', AUD: 'A$', CAD: 'C$', CHF: 'Fr ',
    INR: '₹'
  };
  const symbol = symbols[currencyCode] || `${currencyCode} `;
  return `${symbol}${Number(amount).toLocaleString()}`;
};

// Format a date string nicely
export const formatDate = (dateStr) => {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
};

// Format duration like "9h 45m"
export const formatDuration = (isoOrStr) => {
  if (!isoOrStr) return '';
  // If it's already a formatted string (e.g. "9h 45m"), return as-is
  if (typeof isoOrStr === 'string' && !isoOrStr.startsWith('PT')) return isoOrStr;
  // Parse ISO 8601 duration (e.g. "PT9H45M")
  const match = isoOrStr.match(/PT(\d+H)?(\d+M)?/);
  if (!match) return isoOrStr;
  const hours = match[1] ? parseInt(match[1]) : 0;
  const mins = match[2] ? parseInt(match[2]) : 0;
  return [hours && `${hours}h`, mins && `${mins}m`].filter(Boolean).join(' ');
};

// Short number: 1,50,000 → ₹1.5L
export const shortInr = (amount) => {
  if (!amount) return '₹0';
  if (amount >= 10000000) return `₹${(amount / 10000000).toFixed(1)}Cr`;
  if (amount >= 100000) return `₹${(amount / 100000).toFixed(1)}L`;
  if (amount >= 1000) return `₹${(amount / 1000).toFixed(0)}K`;
  return `₹${Math.round(amount)}`;
};

// Color class based on budget status
export const getBudgetColor = (difference) => {
  if (difference > 0) return 'var(--success)';   // Under budget
  if (difference > -10000) return 'var(--warning)'; // Slightly over
  return 'var(--error)';                           // Over budget
};

// Get emoji for activity type
export const getActivityEmoji = (type) => {
  const map = {
    sightseeing: '🏛️', food: '🍽️', transport: '🚌', relaxation: '🌿',
    adventure: '🧗', shopping: '🛍️', nightlife: '🎭', nature: '🌿',
    culture: '🎨', beach: '🏖️', museum: '🖼️', temple: '🕌',
    market: '🏪', viewpoint: '👁️', cafe: '☕', tour: '🗺️'
  };
  return map[type] || '📍';
};

// Get color for cost optimization difficulty
export const getDifficultyColor = (difficulty) => {
  const map = { easy: 'var(--success)', medium: 'var(--warning)', hard: 'var(--error)' };
  return map[difficulty] || 'var(--text-secondary)';
};

// Truncate long text
export const truncate = (str, maxLen = 80) => {
  if (!str || str.length <= maxLen) return str;
  return str.slice(0, maxLen) + '…';
};
