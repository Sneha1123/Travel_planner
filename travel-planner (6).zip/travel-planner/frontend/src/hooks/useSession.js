// ============================================================
// hooks/useSession.js
// Auto-saves entire app state to localStorage
// Restores on refresh / server restart
// ============================================================

import { useState, useEffect, useRef, useCallback } from 'react';

const SESSION_KEY = 'travel_planner_session';
const CHAT_KEY = 'travel_planner_chat';
const VERSION = '1.0'; // bump if data shape changes

// Debounce helper — don't save on every keystroke
function debounce(fn, delay) {
  let timer;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
}

export function useSession() {
  const [sessionLoaded, setSessionLoaded] = useState(false);

  // ---- Load saved session ----
  const loadSession = useCallback(() => {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const saved = JSON.parse(raw);
      if (saved.version !== VERSION) return null; // stale format
      return saved;
    } catch { return null; }
  }, []);

  // ---- Save session ----
  const saveSession = useCallback((data) => {
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify({
        version: VERSION,
        savedAt: new Date().toISOString(),
        ...data
      }));
    } catch (e) {
      console.warn('Session save failed:', e.message);
    }
  }, []);

  // ---- Clear session ----
  const clearSession = useCallback(() => {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(CHAT_KEY);
  }, []);

  // ---- Save chat history separately ----
  const saveChatHistory = useCallback((messages) => {
    try {
      localStorage.setItem(CHAT_KEY, JSON.stringify(messages));
    } catch {}
  }, []);

  const loadChatHistory = useCallback(() => {
    try {
      const raw = localStorage.getItem(CHAT_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }, []);

  // ---- Get session metadata ----
  const getSessionMeta = useCallback(() => {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const saved = JSON.parse(raw);
      return {
        savedAt: saved.savedAt,
        tripTitle: saved.overview?.tripSummary?.title || 'Unnamed Trip',
        cities: saved.overview?.cityPlan?.map(c => c.city).join(', ') || '',
        expandedDays: Object.keys(saved.expandedDays || {}).length,
        hasOverview: !!saved.overview,
      };
    } catch { return null; }
  }, []);

  return { loadSession, saveSession, clearSession, saveChatHistory, loadChatHistory, getSessionMeta, sessionLoaded, setSessionLoaded };
}
