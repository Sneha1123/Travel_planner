// ============================================================
// hooks/useChecklist.js
// Manages must-do checkboxes across all days
// Persists to localStorage + provides copy/restore text
// ============================================================

import { useState, useEffect, useCallback } from 'react';

const STORAGE_KEY = 'travel_planner_checklist';

export function useChecklist() {
  // checkedItems: { "3_amsterdam_morning": { dayNumber, cityName, slot, label }, ... }
  const [checkedItems, setCheckedItems] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : {};
    } catch { return {}; }
  });

  // Persist to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(checkedItems));
    } catch {}
  }, [checkedItems]);

  const getKey = (dayNumber, slot, label) =>
    `${dayNumber}_${slot}_${label?.replace(/\s+/g, '_').toLowerCase().slice(0, 30)}`;

  const isChecked = useCallback((dayNumber, slot, label) => {
    return !!checkedItems[getKey(dayNumber, slot, label)];
  }, [checkedItems]);

  const toggle = useCallback((dayNumber, cityName, slot, label) => {
    const key = getKey(dayNumber, slot, label);
    setCheckedItems(prev => {
      const next = { ...prev };
      if (next[key]) {
        delete next[key];
      } else {
        next[key] = { dayNumber, cityName, slot, label, addedAt: new Date().toISOString() };
      }
      return next;
    });
  }, []);

  // Get all checked items for a specific day (used when redoing a day)
  const getCheckedForDay = useCallback((dayNumber) => {
    return Object.values(checkedItems).filter(item => item.dayNumber === dayNumber);
  }, [checkedItems]);

  // Generate copy text for all checked items
  const generateCopyText = useCallback(() => {
    const items = Object.values(checkedItems).sort((a, b) => a.dayNumber - b.dayNumber);
    if (!items.length) return '';

    const lines = [
      '✅ MUST-DO LIST — Smart Travel Planner',
      `Saved: ${new Date().toLocaleString('en-IN')}`,
      '==========================================',
      ''
    ];

    // Group by day
    const byDay = {};
    items.forEach(item => {
      const key = `Day ${item.dayNumber} — ${item.cityName}`;
      if (!byDay[key]) byDay[key] = [];
      byDay[key].push(`  ✅ ${item.slot}: ${item.label}`);
    });

    Object.entries(byDay).forEach(([day, entries]) => {
      lines.push(day);
      entries.forEach(e => lines.push(e));
      lines.push('');
    });

    return lines.join('\n');
  }, [checkedItems]);

  // Restore from pasted text
  const restoreFromText = useCallback((text) => {
    if (!text.trim()) return 0;
    const lines = text.split('\n');
    let currentDay = null;
    let currentCity = null;
    let restored = 0;

    lines.forEach(line => {
      // Match day header: "Day 3 — Amsterdam"
      const dayMatch = line.match(/Day (\d+) — (.+)/);
      if (dayMatch) {
        currentDay = parseInt(dayMatch[1]);
        currentCity = dayMatch[2].trim();
        return;
      }
      // Match item: "  ✅ Morning: Anne Frank House"
      const itemMatch = line.match(/✅ (.+?): (.+)/);
      if (itemMatch && currentDay) {
        const slot = itemMatch[1].trim();
        const label = itemMatch[2].trim();
        const key = `${currentDay}_${slot}_${label?.replace(/\s+/g, '_').toLowerCase().slice(0, 30)}`;
        setCheckedItems(prev => ({
          ...prev,
          [key]: { dayNumber: currentDay, cityName: currentCity, slot, label, addedAt: new Date().toISOString() }
        }));
        restored++;
      }
    });
    return restored;
  }, []);

  const clearAll = useCallback(() => setCheckedItems({}), []);

  const count = Object.keys(checkedItems).length;

  return { checkedItems, isChecked, toggle, getCheckedForDay, generateCopyText, restoreFromText, clearAll, count };
}
