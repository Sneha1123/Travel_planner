#!/bin/bash
# ============================================================
# setup.sh — One-click setup for Smart Travel Planner (Mac)
# Run this ONCE to install everything
# ============================================================

set -e  # Stop on any error

echo ""
echo "🌍 Smart Travel Planner — Setup Script"
echo "========================================"
echo ""

# ---- Check Node.js ----
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed."
    echo ""
    echo "Please install it first:"
    echo "  1. Go to https://nodejs.org"
    echo "  2. Download the LTS version"
    echo "  3. Install it"
    echo "  4. Re-run this script"
    exit 1
fi

NODE_VERSION=$(node -v)
echo "✅ Node.js found: $NODE_VERSION"

# ---- Check npm ----
NPM_VERSION=$(npm -v)
echo "✅ npm found: v$NPM_VERSION"
echo ""

# ---- Install root dependencies (concurrently) ----
echo "📦 Installing root dependencies..."
npm install
echo "✅ Root deps installed"
echo ""

# ---- Install backend dependencies ----
echo "📦 Installing backend dependencies..."
cd backend
npm install
cd ..
echo "✅ Backend deps installed"
echo ""

# ---- Install frontend dependencies ----
echo "📦 Installing frontend dependencies..."
cd frontend
npm install
cd ..
echo "✅ Frontend deps installed"
echo ""

# ---- Create .env file if it doesn't exist ----
if [ ! -f "backend/.env" ]; then
    echo "📝 Creating backend/.env from template..."
    cp backend/.env.example backend/.env
    echo "✅ Created backend/.env"
    echo ""
    echo "⚠️  IMPORTANT: You need to add your Anthropic API key!"
    echo ""
    echo "   1. Open the file: backend/.env"
    echo "   2. Replace 'your_anthropic_api_key_here' with your actual key"
    echo "   3. Get your key at: https://console.anthropic.com/"
    echo ""
else
    echo "✅ backend/.env already exists"
fi

# ---- Create exports directory ----
mkdir -p backend/exports
echo "✅ Created backend/exports/ folder (your trip files will save here)"
echo ""

# ---- Done ----
echo "========================================"
echo "✅ Setup complete!"
echo ""
echo "NEXT STEPS:"
echo ""
echo "  1. Add your Anthropic API key to backend/.env"
echo "     (open backend/.env in any text editor)"
echo ""
echo "  2. Start the app:"
echo "     npm run dev"
echo ""
echo "  3. Open in browser:"
echo "     http://localhost:5173"
echo ""
echo "========================================"
