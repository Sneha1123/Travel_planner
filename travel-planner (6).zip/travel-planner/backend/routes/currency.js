// ============================================================
// routes/currency.js — Live currency conversion
// Uses ExchangeRate-API (free tier) to get INR rates
// ============================================================

const express = require('express');
const router = express.Router();
const axios = require('axios');

// Cache exchange rates for 1 hour to avoid hammering the API
let rateCache = {};
let cacheTimestamp = null;
const CACHE_DURATION = 60 * 60 * 1000; // 1 hour

// ---- GET /api/currency/rates ----
// Returns exchange rates for common travel currencies vs INR
router.get('/rates', async (req, res) => {
  try {
    const rates = await getExchangeRates();
    res.json({ rates, timestamp: new Date().toISOString(), source: 'exchangerate-api' });
  } catch (err) {
    // Fallback to hardcoded approximate rates if API fails
    const fallbackRates = getFallbackRates();
    res.json({ rates: fallbackRates, timestamp: new Date().toISOString(), source: 'fallback', note: 'Using approximate rates — set EXCHANGE_RATE_API_KEY for live rates' });
  }
});

// ---- GET /api/currency/convert ----
// Convert amount from one currency to INR
router.get('/convert', async (req, res) => {
  const { amount, from } = req.query;

  if (!amount || !from) {
    return res.status(400).json({ error: 'amount and from are required' });
  }

  try {
    const rates = await getExchangeRates();
    const rate = rates[from.toUpperCase()];

    if (!rate) {
      return res.status(400).json({ error: `Currency ${from} not found` });
    }

    const inrAmount = parseFloat(amount) * rate;
    res.json({
      from: from.toUpperCase(),
      to: 'INR',
      amount: parseFloat(amount),
      inrAmount: Math.round(inrAmount),
      rate,
      formattedInr: `₹${Math.round(inrAmount).toLocaleString('en-IN')}`
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---- Helper: Fetch exchange rates ----
async function getExchangeRates() {
  // Return cached rates if fresh
  if (rateCache && cacheTimestamp && Date.now() - cacheTimestamp < CACHE_DURATION) {
    return rateCache;
  }

  const apiKey = process.env.EXCHANGE_RATE_API_KEY;

  if (!apiKey) {
    console.log('No EXCHANGE_RATE_API_KEY set — using fallback rates');
    return getFallbackRates();
  }

  // Fetch from ExchangeRate-API (base: INR, so we need to invert)
  const response = await axios.get(
    `https://v6.exchangerate-api.com/v6/${apiKey}/latest/USD`
  );

  const usdToInr = response.data.conversion_rates.INR;
  const usdRates = response.data.conversion_rates;

  // Convert all currencies to INR equivalent
  const inrRates = {};
  for (const [currency, usdRate] of Object.entries(usdRates)) {
    inrRates[currency] = usdToInr / usdRate;
  }

  rateCache = inrRates;
  cacheTimestamp = Date.now();

  return inrRates;
}

// ---- Fallback rates (approximate, updated manually) ----
// These are used when no API key is set
function getFallbackRates() {
  return {
    // 1 unit of this currency = X INR (approximate)
    USD: 83.5,
    EUR: 90.2,
    GBP: 105.8,
    AED: 22.7,
    SGD: 62.1,
    THB: 2.35,
    JPY: 0.56,
    AUD: 54.3,
    CAD: 61.5,
    CHF: 93.8,
    HKD: 10.7,
    MYR: 18.9,
    IDR: 0.0054,
    VND: 0.0034,
    PHP: 1.48,
    KRW: 0.063,
    CNY: 11.6,
    NZD: 51.2,
    ZAR: 4.6,
    TRY: 2.7,
    CZK: 3.7,
    PLN: 20.9,
    HUF: 0.23,
    SEK: 8.0,
    NOK: 7.9,
    DKK: 12.1,
    BHD: 221.5,
    QAR: 22.9,
    SAR: 22.3,
    KWD: 271.2,
    OMR: 217.0,
    EGP: 1.73,
    MXN: 4.9,
    BRL: 15.9,
    INR: 1 // Base
  };
}

module.exports = router;
