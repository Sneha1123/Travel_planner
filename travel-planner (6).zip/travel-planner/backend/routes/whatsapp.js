// ============================================================
// routes/whatsapp.js — WhatsApp integration
// Supports: Cloud API send (Meta) + quick share link generation
// ============================================================

const express = require('express');
const router = express.Router();
const axios = require('axios');

// ---- POST /api/whatsapp/send ----
// Send a message via WhatsApp Cloud API
router.post('/send', async (req, res) => {
  const { to, message } = req.body;

  if (!to || !message) {
    return res.status(400).json({ error: 'to and message are required' });
  }

  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  const token = process.env.WHATSAPP_TOKEN;

  if (!phoneNumberId || !token) {
    return res.status(400).json({
      error: 'WhatsApp API not configured. Add WHATSAPP_PHONE_NUMBER_ID and WHATSAPP_TOKEN to backend/.env',
      configured: false
    });
  }

  try {
    // Clean phone number — remove spaces, dashes, +
    const cleanTo = to.replace(/[\s\-\(\)]/g, '').replace(/^\+/, '');

    const response = await axios.post(
      `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`,
      {
        messaging_product: 'whatsapp',
        to: cleanTo,
        type: 'text',
        text: { body: message }
      },
      {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    res.json({ success: true, messageId: response.data.messages?.[0]?.id });
  } catch (err) {
    const errMsg = err?.response?.data?.error?.message || err.message;
    console.error('WhatsApp send error:', errMsg);
    res.status(500).json({ error: errMsg, configured: true });
  }
});

// ---- GET /api/whatsapp/status ----
router.get('/status', (req, res) => {
  res.json({
    configured: !!(process.env.WHATSAPP_PHONE_NUMBER_ID && process.env.WHATSAPP_TOKEN),
    phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID ? '✅ Set' : '❌ Not set',
    token: process.env.WHATSAPP_TOKEN ? '✅ Set' : '❌ Not set',
    recipientNumber: process.env.WHATSAPP_RECIPIENT_NUMBER || ''
  });
});

module.exports = router;
