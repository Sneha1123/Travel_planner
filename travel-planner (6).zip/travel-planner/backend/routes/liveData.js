// ============================================================
// routes/liveData.js — Live flight & hotel price fetching
// Uses Amadeus API for flights, RapidAPI for hotels
// Falls back to mock data if API keys not set
// ============================================================

const express = require('express');
const router = express.Router();
const axios = require('axios');

// ---- GET /api/live/status ----
// Which APIs are connected?
router.get('/status', (req, res) => {
  res.json({
    flights: {
      amadeus: !!process.env.AMADEUS_API_KEY,
      skyscanner: !!process.env.RAPIDAPI_KEY,
      message: process.env.AMADEUS_API_KEY
        ? '✅ Live flight prices available'
        : '⚠️ Mock data only — add AMADEUS_API_KEY for live prices'
    },
    hotels: {
      booking: !!process.env.BOOKING_RAPIDAPI_KEY,
      message: process.env.BOOKING_RAPIDAPI_KEY
        ? '✅ Live hotel prices available'
        : '⚠️ Mock data only — add BOOKING_RAPIDAPI_KEY for live prices'
    }
  });
});

// ---- POST /api/live/flights ----
// Search for live flights or return mock data
router.post('/flights', async (req, res) => {
  const { origin, destination, departureDate, returnDate, cabin, adults } = req.body;

  if (!origin || !destination || !departureDate) {
    return res.status(400).json({ error: 'origin, destination, and departureDate are required' });
  }

  // Try Amadeus API if key is set
  if (process.env.AMADEUS_API_KEY && process.env.AMADEUS_API_SECRET) {
    try {
      const flights = await fetchAmadeusFlights({ origin, destination, departureDate, returnDate, cabin, adults });
      return res.json({ source: 'amadeus_live', flights });
    } catch (err) {
      console.error('Amadeus error:', err.message);
      // Fall through to mock data
    }
  }

  // Return mock data with a note
  const mockFlights = generateMockFlights({ origin, destination, departureDate, cabin });
  res.json({
    source: 'mock',
    note: 'Add AMADEUS_API_KEY to .env for live prices. These are estimated prices.',
    flights: mockFlights
  });
});

// ---- POST /api/live/hotels ----
// Search for live hotels or return mock data
router.post('/hotels', async (req, res) => {
  const { city, checkIn, checkOut, guests, stars, maxPrice } = req.body;

  if (!city || !checkIn || !checkOut) {
    return res.status(400).json({ error: 'city, checkIn, and checkOut are required' });
  }

  // Try Booking.com RapidAPI if key is set
  if (process.env.BOOKING_RAPIDAPI_KEY) {
    try {
      const hotels = await fetchBookingHotels({ city, checkIn, checkOut, guests, stars, maxPrice });
      return res.json({ source: 'booking_live', hotels });
    } catch (err) {
      console.error('Booking.com error:', err.message);
    }
  }

  const mockHotels = generateMockHotels({ city, stars });
  res.json({
    source: 'mock',
    note: 'Add BOOKING_RAPIDAPI_KEY to .env for live hotel prices. These are estimated.',
    hotels: mockHotels
  });
});

// ---- Amadeus API Integration ----
async function fetchAmadeusFlights({ origin, destination, departureDate, returnDate, cabin, adults }) {
  // Step 1: Get access token
  const tokenRes = await axios.post(
    'https://test.api.amadeus.com/v1/security/oauth2/token',
    `grant_type=client_credentials&client_id=${process.env.AMADEUS_API_KEY}&client_secret=${process.env.AMADEUS_API_SECRET}`,
    { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
  );
  const token = tokenRes.data.access_token;

  // Step 2: Search flights
  const params = {
    originLocationCode: origin,
    destinationLocationCode: destination,
    departureDate,
    adults: adults || 1,
    travelClass: cabin || 'ECONOMY',
    max: 10
  };
  if (returnDate) params.returnDate = returnDate;

  const flightRes = await axios.get(
    'https://test.api.amadeus.com/v2/shopping/flight-offers',
    { params, headers: { Authorization: `Bearer ${token}` } }
  );

  return flightRes.data.data.map(offer => ({
    id: offer.id,
    price: parseFloat(offer.price.total),
    currency: offer.price.currency,
    airline: offer.validatingAirlineCodes?.[0],
    duration: offer.itineraries[0].duration,
    stops: offer.itineraries[0].segments.length - 1,
    departure: offer.itineraries[0].segments[0].departure,
    arrival: offer.itineraries[0].segments.slice(-1)[0].arrival,
    bookingLink: `https://www.google.com/travel/flights?q=flights+${origin}+to+${destination}+${departureDate}`
  }));
}

// ---- Booking.com via RapidAPI ----
async function fetchBookingHotels({ city, checkIn, checkOut, guests, stars }) {
  const response = await axios.get(
    'https://booking-com.p.rapidapi.com/v1/hotels/search',
    {
      params: {
        dest_type: 'city',
        dest_id: city,
        checkin_date: checkIn,
        checkout_date: checkOut,
        adults_number: guests || 2,
        room_number: 1,
        order_by: 'popularity',
        filter_by_currency: 'USD',
        locale: 'en-gb',
        units: 'metric',
        page_number: 0,
        include_adjacency: true
      },
      headers: {
        'X-RapidAPI-Key': process.env.BOOKING_RAPIDAPI_KEY,
        'X-RapidAPI-Host': 'booking-com.p.rapidapi.com'
      }
    }
  );

  return response.data.result?.map(hotel => ({
    id: hotel.hotel_id,
    name: hotel.hotel_name,
    stars: hotel.stars,
    reviewScore: hotel.review_score,
    pricePerNight: hotel.price_breakdown?.gross_price,
    currency: hotel.currency_code,
    address: hotel.address,
    imageUrl: hotel.main_photo_url,
    bookingLink: hotel.url
  }));
}

// ---- Mock Data Generators ----
// Used when no API keys are set. Realistic estimates.
function generateMockFlights({ origin, destination, departureDate, cabin }) {
  const cabinMultiplier = { ECONOMY: 1, PREMIUM_ECONOMY: 1.8, BUSINESS: 3.5, FIRST: 6 };
  const mult = cabinMultiplier[cabin] || 1;

  // Base prices by rough region distance (very approximate)
  const basePrice = 450 * mult;

  return [
    {
      id: 'mock1',
      airline: 'Emirates',
      price: Math.round(basePrice * 0.9),
      currency: 'USD',
      duration: '9h 45m',
      stops: 1,
      stopCity: 'Dubai',
      departure: `${departureDate}T06:00:00`,
      arrival: `${departureDate}T20:45:00`,
      bookingLink: `https://www.google.com/travel/flights`,
      isMock: true
    },
    {
      id: 'mock2',
      airline: 'Air India',
      price: Math.round(basePrice * 0.85),
      currency: 'USD',
      duration: '8h 30m',
      stops: 0,
      stopCity: null,
      departure: `${departureDate}T22:00:00`,
      arrival: `${departureDate}T07:30:00+1`,
      bookingLink: `https://www.airindia.com`,
      isMock: true
    },
    {
      id: 'mock3',
      airline: 'IndiGo',
      price: Math.round(basePrice * 0.78),
      currency: 'USD',
      duration: '11h 20m',
      stops: 1,
      stopCity: 'Singapore',
      departure: `${departureDate}T14:00:00`,
      arrival: `${departureDate}T06:20:00+1`,
      bookingLink: `https://www.goindigo.in`,
      isMock: true
    }
  ];
}

function generateMockHotels({ city, stars }) {
  const starLevel = stars || 4;
  const basePrice = starLevel * 40;

  return [
    {
      id: 'hotel_mock1',
      name: `The Grand ${city} Hotel`,
      stars: starLevel,
      reviewScore: 8.4,
      pricePerNight: basePrice,
      currency: 'USD',
      area: 'City Center',
      bookingLink: `https://www.booking.com/searchresults.html?ss=${encodeURIComponent(city)}`,
      isMock: true
    },
    {
      id: 'hotel_mock2',
      name: `${city} Boutique Residence`,
      stars: Math.max(3, starLevel - 1),
      reviewScore: 9.1,
      pricePerNight: Math.round(basePrice * 0.7),
      currency: 'USD',
      area: 'Old Town',
      bookingLink: `https://www.airbnb.com/s/${encodeURIComponent(city)}/homes`,
      isMock: true
    }
  ];
}

module.exports = router;
