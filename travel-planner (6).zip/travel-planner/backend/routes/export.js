// ============================================================
// routes/export.js — Save trip data to local files
// Supports JSON (full data) and CSV (budget breakdown)
// ============================================================

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Create exports directory if it doesn't exist
const EXPORTS_DIR = path.join(__dirname, '../exports');
if (!fs.existsSync(EXPORTS_DIR)) {
  fs.mkdirSync(EXPORTS_DIR, { recursive: true });
}

// ---- POST /api/export/trip ----
// Save the full trip plan as JSON + CSV
router.post('/trip', (req, res) => {
  try {
    const { tripData, itinerary, manualEntries } = req.body;

    if (!itinerary) {
      return res.status(400).json({ error: 'itinerary data is required' });
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const tripTitle = itinerary.tripSummary?.title?.replace(/[^a-zA-Z0-9]/g, '_') || 'MyTrip';
    const baseName = `${tripTitle}_${timestamp}`;

    // ---- Save full JSON ----
    const jsonPath = path.join(EXPORTS_DIR, `${baseName}.json`);
    const fullData = {
      exportedAt: new Date().toISOString(),
      tripInputs: tripData,
      itinerary,
      manualEntries: manualEntries || [],
      copyPasteData: generateCopyPasteText(itinerary, manualEntries)
    };
    fs.writeFileSync(jsonPath, JSON.stringify(fullData, null, 2), 'utf8');

    // ---- Save CSV budget breakdown ----
    const csvPath = path.join(EXPORTS_DIR, `${baseName}_budget.csv`);
    const csvContent = generateBudgetCSV(itinerary);
    fs.writeFileSync(csvPath, csvContent, 'utf8');

    // ---- Save human-readable text ----
    const txtPath = path.join(EXPORTS_DIR, `${baseName}_itinerary.txt`);
    const txtContent = generateCopyPasteText(itinerary, manualEntries);
    fs.writeFileSync(txtPath, txtContent, 'utf8');

    res.json({
      success: true,
      files: {
        json: jsonPath,
        csv: csvPath,
        txt: txtPath
      },
      copyPasteText: txtContent,
      message: `Trip saved! Files are in: ${EXPORTS_DIR}`
    });

  } catch (err) {
    console.error('Export error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ---- POST /api/export/manual-entry ----
// Save a manual link/price entry
router.post('/manual-entry', (req, res) => {
  try {
    const entriesPath = path.join(EXPORTS_DIR, 'manual_entries.json');

    // Load existing entries
    let entries = [];
    if (fs.existsSync(entriesPath)) {
      entries = JSON.parse(fs.readFileSync(entriesPath, 'utf8'));
    }

    // Add new entry with timestamp
    const newEntry = {
      id: Date.now().toString(),
      savedAt: new Date().toISOString(),
      ...req.body
    };
    entries.push(newEntry);

    // Save back
    fs.writeFileSync(entriesPath, JSON.stringify(entries, null, 2), 'utf8');

    res.json({ success: true, entry: newEntry, totalEntries: entries.length });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---- GET /api/export/manual-entries ----
// Get all saved manual entries
router.get('/manual-entries', (req, res) => {
  try {
    const entriesPath = path.join(EXPORTS_DIR, 'manual_entries.json');
    if (!fs.existsSync(entriesPath)) {
      return res.json({ entries: [] });
    }
    const entries = JSON.parse(fs.readFileSync(entriesPath, 'utf8'));
    res.json({ entries });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---- Helper: Generate CSV budget breakdown ----
function generateBudgetCSV(itinerary) {
  const bd = itinerary.budgetBreakdown || {};
  const lines = [
    'Category,Local Currency,Amount (Local),INR Amount',
    `Outbound Flight,${bd.currency},${bd.flights?.outbound || 0},${bd.flights?.outbound * bd.exchangeRateToInr || 0}`,
    `Return Flight,${bd.currency},${bd.flights?.return || 0},${bd.flights?.return * bd.exchangeRateToInr || 0}`,
    `Intercity Flights,${bd.currency},${bd.flights?.intercity || 0},${bd.flights?.intercity * bd.exchangeRateToInr || 0}`,
    `Accommodation,${bd.currency},${bd.accommodation?.total || 0},${bd.accommodation?.totalInr || 0}`,
    `Intercity Transport,${bd.currency},${bd.intercityTransport?.total || 0},${bd.intercityTransport?.totalInr || 0}`,
    `Local Transport,${bd.currency},${bd.localTransport?.total || 0},${bd.localTransport?.totalInr || 0}`,
    `Food,${bd.currency},${bd.food?.total || 0},${bd.food?.totalInr || 0}`,
    `Activities,${bd.currency},${bd.activities?.total || 0},${bd.activities?.totalInr || 0}`,
    `Misc/Buffer,${bd.currency},${bd.miscBuffer?.total || 0},${bd.miscBuffer?.totalInr || 0}`,
    `---,---,---,---`,
    `GRAND TOTAL,${bd.currency},${bd.grandTotal || 0},${bd.grandTotalInr || 0}`,
    `Per Person,${bd.currency},${bd.perPerson || 0},${bd.perPersonInr || 0}`,
    `Per Day,${bd.currency},${bd.perDay || 0},${bd.perDayInr || 0}`,
    `Target Budget,${bd.currency},${bd.targetBudget || 0},`,
    `Budget Difference,${bd.currency},${bd.budgetDifference || 0},`,
  ];

  // Add daily costs
  if (itinerary.dailyItinerary?.length > 0) {
    lines.push('', 'Day-wise Breakdown,,,');
    lines.push('Day,City,Date,Total Cost (INR)');
    itinerary.dailyItinerary.forEach(day => {
      lines.push(`Day ${day.day},${day.city},${day.date},${day.totalDayCostInr || 0}`);
    });
  }

  return lines.join('\n');
}

// ---- Helper: Generate plain-text copy-paste format ----
function generateCopyPasteText(itinerary, manualEntries) {
  const bd = itinerary?.budgetBreakdown || {};
  const summary = itinerary?.tripSummary || {};

  let text = `
==========================================
🌍 SMART TRAVEL PLANNER — TRIP SUMMARY
==========================================
Generated: ${new Date().toLocaleString('en-IN')}
Trip: ${summary.title || 'My Trip'}
${summary.description || ''}

==========================================
✈️  FLIGHTS
==========================================
`;

  // Outbound flight
  const outbound = itinerary?.flights?.outbound;
  if (outbound) {
    text += `
OUTBOUND: ${outbound.from} → ${outbound.to}
Estimated Price: ${outbound.currency} ${outbound.estimatedPrice} (₹${outbound.inrEquivalent?.toLocaleString('en-IN')})
Duration: ${outbound.duration} | Stops: ${outbound.stops}
Airlines: ${outbound.recommendedAirlines?.join(', ')}
Book Here:
  - Google Flights: ${outbound.bookingLinks?.googleFlights}
  - Skyscanner: ${outbound.bookingLinks?.skyscanner}
  - MakeMyTrip: ${outbound.bookingLinks?.makemytrip}
Tip: ${outbound.tip}
`;
  }

  // Hotels
  text += `
==========================================
🏨  HOTELS
==========================================
`;
  itinerary?.hotels?.forEach(hotel => {
    text += `
${hotel.city} — ${hotel.hotelName} (${hotel.stars}★)
Area: ${hotel.area} | Type: ${hotel.type}
Price: ${hotel.currency} ${hotel.pricePerNight}/night (₹${hotel.inrPerNight?.toLocaleString('en-IN')}/night)
Total Stay: ₹${hotel.totalInr?.toLocaleString('en-IN')}
Why: ${hotel.whyRecommended}
Book Here:
  - Booking.com: ${hotel.bookingLinks?.booking}
  - Airbnb: ${hotel.bookingLinks?.airbnb}
  - Google Hotels: ${hotel.bookingLinks?.googleHotels}
Maps: ${hotel.mapsLink}
`;
  });

  // Daily Itinerary
  text += `
==========================================
📅  DAY-WISE ITINERARY
==========================================
`;
  itinerary?.dailyItinerary?.forEach(day => {
    text += `
--- DAY ${day.day}: ${day.date} | ${day.city} ---
Theme: ${day.theme}

🌅 MORNING (${day.morning?.time}): ${day.morning?.activity}
   ${day.morning?.description}
   Cost: ₹${day.morning?.inrCost?.toLocaleString('en-IN')} | Duration: ${day.morning?.duration}
   Maps: ${day.morning?.mapsLink}
   ${day.morning?.tip ? `Tip: ${day.morning?.tip}` : ''}

☀️  AFTERNOON (${day.afternoon?.time}): ${day.afternoon?.activity}
   ${day.afternoon?.description}
   Cost: ₹${day.afternoon?.inrCost?.toLocaleString('en-IN')} | Duration: ${day.afternoon?.duration}
   Maps: ${day.afternoon?.mapsLink}

🌙 EVENING (${day.evening?.time}): ${day.evening?.activity}
   ${day.evening?.description}
   Cost: ₹${day.evening?.inrCost?.toLocaleString('en-IN')} | Duration: ${day.evening?.duration}

🍽️  FOOD:
   Breakfast: ${day.food?.breakfast?.place} (${day.food?.breakfast?.type}) — ₹${day.food?.breakfast?.inrCost}
   Lunch: ${day.food?.lunch?.place} (${day.food?.lunch?.type}) — ₹${day.food?.lunch?.inrCost}
   Dinner: ${day.food?.dinner?.place} (${day.food?.dinner?.type}) — ₹${day.food?.dinner?.inrCost}

🚌 LOCAL TRANSPORT: ${day.localTransport?.mode} — ₹${day.localTransport?.inrCost}
   ${day.localTransport?.tip}

💰 TOTAL DAY COST: ₹${day.totalDayCostInr?.toLocaleString('en-IN')}
${day.notes ? `📝 Notes: ${day.notes}` : ''}
`;
  });

  // Budget Summary
  text += `
==========================================
💰  BUDGET BREAKDOWN
==========================================
Exchange Rate: 1 ${bd.currency} = ₹${bd.exchangeRateToInr}

Flights (Total):        ₹${bd.flights?.totalInr?.toLocaleString('en-IN')}
Accommodation:          ₹${bd.accommodation?.totalInr?.toLocaleString('en-IN')}
Intercity Transport:    ₹${bd.intercityTransport?.totalInr?.toLocaleString('en-IN')}
Local Transport:        ₹${bd.localTransport?.totalInr?.toLocaleString('en-IN')}
Food:                   ₹${bd.food?.totalInr?.toLocaleString('en-IN')}
Activities:             ₹${bd.activities?.totalInr?.toLocaleString('en-IN')}
Buffer (10-15%):        ₹${bd.miscBuffer?.totalInr?.toLocaleString('en-IN')}
------------------------------------------
GRAND TOTAL:            ₹${bd.grandTotalInr?.toLocaleString('en-IN')}
Per Person:             ₹${bd.perPersonInr?.toLocaleString('en-IN')}
Per Day:                ₹${bd.perDayInr?.toLocaleString('en-IN')}
Target Budget:          ₹${bd.targetBudget?.toLocaleString('en-IN')}
Difference:             ₹${bd.budgetDifferenceInr?.toLocaleString('en-IN')} ${bd.isOverBudget ? '(OVER BUDGET)' : '(WITHIN BUDGET ✅)'}
`;

  // Manual entries
  if (manualEntries?.length > 0) {
    text += `
==========================================
📌  MANUALLY ADDED ENTRIES
==========================================
`;
    manualEntries.forEach((entry, i) => {
      text += `
Entry ${i + 1}: ${entry.type?.toUpperCase()} — ${entry.title}
  Price: ${entry.currency} ${entry.price} (₹${entry.inrAmount})
  Link: ${entry.link}
  Notes: ${entry.notes || 'None'}
  Added: ${entry.savedAt || 'N/A'}
`;
    });
  }

  text += `
==========================================
Generated by Smart Travel Planner
==========================================
`;

  return text;
}

module.exports = router;
