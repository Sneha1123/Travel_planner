// ============================================================
// server.js — Main Express Backend Server
// Handles all API routes for the Smart Travel Planner
// ============================================================

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const aiRoutes = require('./routes/ai');
const currencyRoutes = require('./routes/currency');
const liveDataRoutes = require('./routes/liveData');
const exportRoutes = require('./routes/export');
const whatsappRoutes = require('./routes/whatsapp');

const app = express();
const PORT = process.env.PORT || 3001;

// ---- Middleware ----
app.use(cors({ origin: 'http://localhost:5173' })); // Vite default port
app.use(express.json({ limit: '10mb' }));

// Rate limiting — prevents accidental API hammering
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: { error: 'Too many requests, please wait a moment.' }
});
app.use('/api/', limiter);

// ---- Routes ----
app.use('/api/ai', aiRoutes);
app.use('/api/currency', currencyRoutes);
app.use('/api/live', liveDataRoutes);
app.use('/api/export', exportRoutes);
app.use('/api/whatsapp', whatsappRoutes);

// ---- Health Check ----
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'Smart Travel Planner backend is running!',
    apis: {
      anthropic: !!process.env.ANTHROPIC_API_KEY,
      amadeus: !!process.env.AMADEUS_API_KEY,
      rapidapi: !!process.env.RAPIDAPI_KEY,
      exchangeRate: !!process.env.EXCHANGE_RATE_API_KEY,
      whatsapp: !!(process.env.WHATSAPP_PHONE_NUMBER_ID && process.env.WHATSAPP_TOKEN)
    }
  });
});

// ---- Start Server ----
app.listen(PORT, () => {
  console.log(`\n🌍 Smart Travel Planner Backend running on http://localhost:${PORT}`);
  console.log(`📋 API keys loaded:`);
  console.log(`   Anthropic:     ${process.env.ANTHROPIC_API_KEY ? '✅' : '❌ (required)'}`);
  console.log(`   Amadeus:       ${process.env.AMADEUS_API_KEY ? '✅' : '⚠️  (optional - for live flights)'}`);
  console.log(`   RapidAPI:      ${process.env.RAPIDAPI_KEY ? '✅' : '⚠️  (optional - for live hotels)'}`);
  console.log(`   Exchange Rate: ${process.env.EXCHANGE_RATE_API_KEY ? '✅' : '⚠️  (optional - for INR conversion)'}`);
  console.log(`\n   Frontend should be running on http://localhost:5173\n`);
});
